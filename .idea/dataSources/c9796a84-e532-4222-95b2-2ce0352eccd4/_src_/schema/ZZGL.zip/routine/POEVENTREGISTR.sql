CREATE procedure POEVENTREGISTR(f_address         in varchar2,--干系人住址
                                           f_evt_level       in varchar2,--案事件登记
                                           f_evt_type        in varchar2,--案事件类型
                                           f_bigtype_name    in varchar2,--大类name
                                           f_bigtype_id      in number,--大类id
                                           f_smalltype_name  in varchar2,--小类name
                                           f_smalltype_id    in number,--小类id
                                           regionid          in number,--所属地区id
                                           f_evt_address     in varchar2,--所属地区name
                                           f_gridid          in number,--网格id
                                           f_evt_description in varchar2,--描述
                                           f_eva_opi         in varchar2,--办理意见
                                           img               in varchar2,--多媒体图片
                                           audio             in varchar2,--多媒体音频
                                           video             in varchar2,--多媒体视频
                                           f_humanid         in number,
                                           x                 in varchar2,--经度
                                           y                 in varchar2,--纬度
                                           fdtwz             in varchar2,--地图位置      
                                           resultS           out integer)
                                           as
  recno varchar2(100);
  next_Node NUMBER;
  act_Id NUMBER;
  overHour NUMBER;
  /*
   功能：指挥中心 事案件上报
   作者：宋园园
   时间：2016-03-20
   版本：0.1
   参数：
       
       返回值：
         0 成功
         1 失败
   修改：
      修改人：程清雷
      修改时间：2016-03-31
      版本：0.2
      修改内容：
          修改上报时活动表的记录
     修改：
      修改人：李鹏飞
      修改时间：2016-04-05
      修改内容：
       t_base_event 增加 经度 纬度，gisid的存储
   */
begin
  recno := foGetRecNo();
  insert into T_BASE_EVENT t
    (t.f_id,
     t.f_address,
     t.f_evt_level,
     t.f_evt_type,
     t.f_bigtype_name,
     t.f_bigtype_id,
     t.f_smalltype_name,
     t.f_smalltype_id,
     t.f_gridid,
     t.regionid,
     t.f_evt_address,
     t.f_evt_description,
     t.f_eva_opi,
     t.F_NODE_ID,t.F_Evt_No,t.F_Resource,t.f_x,t.f_y,t.F_GISID)
  values
    (seq_base_event.nextval,
     f_address,
     f_evt_level,
     f_evt_type,
     f_bigtype_name,
     f_bigtype_id,
     f_smalltype_name,
     f_smalltype_id,
     f_gridid,
     regionid,
     f_evt_address,
     f_evt_description,
     f_eva_opi,
     1,recno,1,x,y,fdtwz);

  --记录多媒体信息 T_REC_MEDIA
  if img is not null then
        for i in 1..foStrArrayLength(img,',') loop
            insert into  T_REC_MEDIA t(t.id,t.recid,t.mediatype,t.medianame)
            values(seq_rec_medis.nextval,recno,0,foStrArrayStrOfIndex(img,',',i-1));
        end loop;
    end if;
    if audio is not null then
       for j in 1..foStrArrayLength(audio,',') loop
           insert into  T_REC_MEDIA t(t.id,t.recid,t.mediatype,t.medianame)
            values(seq_rec_medis.nextval,recno,1,foStrArrayStrOfIndex(audio,',',j-1));

        end loop;
    end if;
    if video is not null then
       for k in 1..foStrArrayLength(video,',') loop
            insert into  T_REC_MEDIA t(t.id,t.recid,t.mediatype,t.medianame)
             values(seq_rec_medis.nextval,recno,2,foStrArrayStrOfIndex(video,',',k-1));
       end loop;
    end if;
  
  
    --增加活动表 by 程清雷
    
    --获取上报后的下一节点
    select n.f_nextnodeid into next_Node from t_Wf_Node_Dic n where n.f_nodeid = 1 and n.F_PROCESSID = 100;
    
    --插入上报动作信息
    insert into t_Rec_Act m (m.F_Evt_No,F_AcceptedId,F_NodeId,F_State,F_CompletionDate,F_ACCEPTEDDATE)values(recno,f_humanid,1,1,sysdate,sysdate);
    
    --或得下一节点的超期时限
    select d.f_complimited into overHour from t_Wf_Node_Dic d where d.f_nodeid = next_Node and d.F_PROCESSID = 100;
    
    --插入下一节点相关信息
    insert into t_Rec_Act a (a.F_Evt_No,a.F_ACCEPTEDID,a.F_NodeId,a.F_State,F_OVERDATE)values(recno,'',next_Node,2,sysdate+(overHour/24));
  
    --记录最新活动标识
    select max(F_Id) into act_Id from t_Rec_Act where F_Evt_No = recno;
    
    --更新主表
    update t_Base_Event set F_Act_Id = nvl(act_Id,-1) where F_Evt_No = recno;
  
  resultS := 0;
  commit;
exception
  when others then
    rollback;
    resultS := 1;
  
end POEVENTREGISTR;
/
