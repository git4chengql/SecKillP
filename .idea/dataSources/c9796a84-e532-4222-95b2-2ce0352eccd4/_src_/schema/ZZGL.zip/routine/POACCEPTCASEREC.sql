CREATE procedure poAcceptCaseRec(recType in varchar2,
                                        recName in varchar2,
                                        recResource in integer
                                        
                                        )
as
begin
 null;
end;
/
