CREATE procedure PoDeleteSpecialAndPeople(
                                           fid       in number,--户籍表的主键
                                           resultS       out integer) as
  /**
  作者：李鹏飞
  功能：删除户籍人口的时候 如果特殊人群下有此人，把此人删除，并把户籍表中的标志改变
  时间：2016-07-25
  */
   idcard varchar2(500);
begin
  select t.f_id_card into idcard    from t_psn_resident t  where t.f_id = fid;
    /*
  留守人员
  */
  delete from T_PSN_LSRY   where  f_persionid=idcard;
   update t_psn_resident t set t.f_lsry=0 where t.f_id_card=idcard;
      /*
  刑满释放
  */
    delete from T_SPEC_COMP_PRISION   where  f_id_num=idcard;
   update t_psn_resident t set t.f_xmsf=0 where t.f_id_card=idcard;
      /*
  社区矫正
  */
   delete from T_SPEC_COMM   where  f_id_num=idcard;
   update t_psn_resident t set t.f_sqjz=0 where t.f_id_card=idcard;
     /*
  严重精神病
  */
   delete from T_SPEC_PSYCHOSIS   where  f_id_num=idcard;
   update t_psn_resident t set t.f_jsza=0 where t.f_id_card=idcard;
    /*
  吸毒
  */
   delete from T_SPEC_DRUG   where  f_id_num=idcard;
   update t_psn_resident t set t.f_xdry=0 where t.f_id_card=idcard;
        /*
  艾滋病
  */
   delete from T_SPEC_ADIS   where  f_id_num=idcard;
   update t_psn_resident t set t.f_aids=0 where t.f_id_card=idcard;
   /*
  重点青少年
  */
   delete from T_YOUN_EMP_TEEN   where  f_id_num=idcard;
   update t_psn_resident t set t.f_zdqsn=0 where t.f_id_card=idcard;
   /*
   户籍人口
   */
   delete from t_psn_resident t7   where  t7.f_id=fid;
  resultS := 0;
  commit;

exception

  when others then
    rollback;
    resultS := 1;
end PoDeleteSpecialAndPeople;
/
