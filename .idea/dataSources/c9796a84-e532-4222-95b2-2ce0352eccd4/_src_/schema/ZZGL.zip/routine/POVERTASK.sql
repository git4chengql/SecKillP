CREATE procedure PoVerTask     (fajbh         in varchar2, --案卷编号
                                           ftype         in number, --t_base_event 表更改为核查
                                           feedbck       in varchar2,--核查意见
                                           resultS       out integer) as
  /**
  作者：李鹏飞
  功能：核查
  时间：2016-04-29
  版本：0.1
  返回值：
      0 成功
      1 失败


  */

begin
  --核查任务表插一条记录
  insert into t_ver_task (F_EVT_NO, F_FEEDBCK)values(fajbh, feedbck);
 --更新t_base_event表中的活动状态
  update t_Base_Event t set t.f_active_status = ftype where t.f_evt_no = fajbh;
  
  resultS := 0;
  commit;
exception
  when others then
    rollback;
    resultS := 1;
end PoVerTask;
/
