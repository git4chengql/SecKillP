CREATE procedure poaddlogandpic(
                              img in  varchar2,
                              f_humanid in number,
                              f_title in varchar2,
                              f_body in varchar2,
                              todate in varchar2,
                              resultS out integer
                             )
  is
     recno VARCHAR2(20);
  begin

    recno := foGetRecNo();
    
    insert into t_log t(t.f_humanid,t.f_title,t.f_body,t.f_log_no,t.f_todate) values(f_humanid,f_title,f_body,recno,to_date(todate,'yyyy-mm-dd'));

    
    
    if img is not null then
        for i in 1..foStrArrayLength(img,',') loop
            insert into t_log_pic t(t.f_pic_name,t.f_log_no) values(foStrArrayStrOfIndex(img,',',i-1),recno);
        end loop;
    end if;


    resultS:=0;
    commit;
 exception
    when others then
        rollback;
        resultS:=1;
 end poaddlogandpic;
/
