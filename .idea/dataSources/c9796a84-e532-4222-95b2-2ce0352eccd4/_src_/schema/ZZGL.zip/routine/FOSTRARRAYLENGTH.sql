CREATE function foStrArrayLength
(
  av_str varchar2,  --要分割的字符串
  av_split varchar2  --分隔符号
)
return number
is
  lv_str varchar2(1000);
  lv_length number;
begin
  lv_str:=ltrim(rtrim(av_str));
  lv_length:=0;
  while instr(lv_str,av_split)<>0 loop
     lv_length:=lv_length+1;
     lv_str:=substr(lv_str,instr(lv_str,av_split)+length(av_split),length(lv_str));
  end loop;
  lv_length:=lv_length+1;
  return lv_length;
end foStrArrayLength;
/
