CREATE FUNCTION FoCheckIsOverTime2
(proid in varchar2) RETURN NUMBER AS
--任务节点的创建时间
createdate timestamp;
--activiti中的任务节点的task_def_key
taskkey varchar2(255);
tnum number;
result number;
/**
  功能：检测是否超时
  返回值：
     0 未超时
     1 即将到期
     2 超期
  
 */
BEGIN
  select t.create_time_,t.task_def_key_ into createdate,taskkey from act_ru_task t where t.proc_inst_id_=proid;
  select (sysdate-(createdate+0))*24 into tnum from dual;
  dbms_output.put_line(tnum);
  if taskkey='usertask1' or taskkey='usertask2' or taskkey='usertask3' or taskkey='usertask5' or taskkey='usertask9' or taskkey='usertask7' then
     if tnum<1 then
        result:=0;
     end if;
     if tnum>=1 and tnum<2  then
        result:=1;
     end if;
     if tnum>=2 then
        result:=2;
     end if;
  end if;
  if taskkey='usertask4' or taskkey='usertask8' or taskkey='usertask6' then
     if tnum<12 then
        result:=0;
     end if;
     if tnum>=12 and tnum<24 then
        result:=1;
     end if;
     if tnum>=24 then
        result:=2;
     end if;
  end if;
  return result;
  EXCEPTION
     when others then
       result:=0;
    return result;
END;
/
