CREATE procedure PoSupervise(recNo         in varchar2, --案卷编号
                                        humanId       in number, --类型，督办或者申请延期
                                        fbz           in varchar2, --备注
                                        factivestatus in number, --活动状态
                                        resultS       out integer) as
  /**
  作者：程清雷
  功能：督办
  时间：2016-03-21
  版本：0.1
  返回值：
      0 成功
      1 失败

  */
  nodeId integer;
begin
  --获取此案卷目前的节点信息
  select F_NODE_ID into nodeId from t_Base_Event where F_Evt_No = recNo;

  insert into t_Rec_Act(F_Evt_No, f_Acceptedid, f_Nodeid, f_State, F_FeedBack, f_Accepteddate)
        values (recNo, humanId, nodeId, factivestatus, fbz, sysdate);
        
    update t_base_event t  set t.f_active_status= factivestatus where t.f_evt_no=recNo;  
  resultS := 0;
  commit;
exception
  when others then
    rollback;
    resultS := 1;
end PoSupervise;
/
