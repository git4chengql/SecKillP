CREATE function foGetRecNo return varchar AS
recNo varchar2(20);
/**
  功能：产生案卷序列号
  作者：程清雷
  日期：2016-03-20
  返回值：
       返回12位案卷编号
 */
begin
  select rtrim(to_char(sysdate,'yyyymmdd'))||ltrim(to_char(SEQ_RECNO.Nextval,'00000')) into recNo from dual;
  return trim(recNo);
end;
/
