CREATE function foRecBack(recNo     in varchar2,
                                     facceptid in integer) return integer as
  /**
   功能：案卷派遣后回退到受理状态
   作者：李鹏飞
   时间：2016-04-22
   参数说明：
      nodeid  t_base_event 更改的数据
      activeid  t_base_event 更改的数据
      recNo 案卷编号
    返回参数
       0 成功
       1 失败
  */
  rectid_max        integer;
  rectnodeid        integer;
  fnodetype          integer;
  fnodeid            integer;


  rectid_forback     integer;
begin
  select max(f_id) into rectid_max from t_rec_act where F_EVT_NO = recNo;
  select s.f_nodeid into rectnodeid from t_rec_act s where s.f_id=rectid_max;
  select a.f_nodetype into fnodetype  from t_wf_node_dic a   where a.f_nodeid=rectnodeid;
  select b.f_nextnodeid into fnodeid   from t_wf_node_dic  b  where b.f_nodeid=fnodetype;
  --fnodeid  需要回退的t_base_event 表中的F_NODE_ID 字段数据
  

   
  --更新t_Base_Event表中的 f_active_status和f_node_id数据
  update t_Base_Event a
     set a.f_active_status = 2,
         a.F_NODE_ID = fnodeid
   where F_Evt_No = recNo;

  insert into t_rec_act
    (F_EVT_NO, F_ACCEPTEDID, F_NODEID, F_STATE, F_FEEDBACK,F_ACCEPTEDDATE)
  values
    (recNo, facceptid, fnodeid, fnodeid, '回退',sysdate);

  select max(f_id)
    into rectid_forback
    from t_rec_act
   where F_EVT_NO = recNo;

  --回退完毕
  update t_Base_Event e
     set e.F_ACT_ID = rectid_forback
   where F_Evt_No = recNo;
  commit;
  return 0;
Exception
  when others then
    rollback;
    return 1;
end foRecBack;
/
