CREATE procedure poaddeventandmedianew(
                              img in   varchar2,
                              song in   varchar2,
                              video in   varchar2,
                              f_evt_description in varchar2,
                              f_bigtype_id in number,
                              f_smalltype_id in number,
                              f_bigtype_name in  varchar2,
                              f_smalltype_name in  varchar2,
                              x in number,
                              y in number,
                              f_humanid in number,
                              f_evt_name in  varchar2,
                              f_gisid in varchar2,
                              f_gridid in number,
                              recno in   varchar2,
                              f_Status in number,
                              f_evt_date in varchar2,
                              f_case_scale in varchar2,
                              f_person_num in varchar2,
                              f_mainpsnidnum in varchar2,
                              f_name in varchar2,
                              f_nation in varchar2,                                             
                              resultS out integer
                             )
  is

     evt_type NUMBER(10);

  begin



    select e.f_type into evt_type from tcdiceventtype e where e.typeid=f_bigtype_id;
    insert into T_BASE_EVENT t( t.f_id,t.f_evt_description,t.f_evt_no,t.f_bigtype_id,t.f_smalltype_id,t.f_x,t.f_y,t.F_REPORTER,t.f_gisid,t.f_bigtype_name,t.f_smalltype_name,t.F_RESOURCE,t.f_gridid,t.F_NODE_ID,F_EVT_TYPE,t.f_evt_name
    ,t.f_evt_date,t.f_case_scale,t.f_person_num,t.f_mainpsnidnum,t.f_name,t.f_nation,t.F_ACTIVE_STATUS)

     values(seq_base_event.nextval,f_evt_description,recno,f_bigtype_id,f_smalltype_id,x,y,f_humanid,f_gisid,f_bigtype_name,f_smalltype_name,0,f_gridid,2,evt_type,f_evt_name,f_evt_date,f_case_scale,f_person_num,f_mainpsnidnum,f_name,f_nation,f_Status);
    if img is not null then
        for i in 1..foStrArrayLength(img,',') loop
            insert into  T_REC_MEDIA t(t.id,t.recid,t.mediatype,t.medianame)
            values(seq_rec_medis.nextval,recno,0,foStrArrayStrOfIndex(img,',',i-1));
        end loop;
    end if;
    if song is not null then
       for j in 1..foStrArrayLength(song,',') loop
           insert into  T_REC_MEDIA t(t.id,t.recid,t.mediatype,t.medianame)
            values(seq_rec_medis.nextval,recno,1,foStrArrayStrOfIndex(song,',',j-1));

        end loop;
    end if;
    if video is not null then
       for k in 1..foStrArrayLength(video,',') loop
            insert into  T_REC_MEDIA t(t.id,t.recid,t.mediatype,t.medianame)
             values(seq_rec_medis.nextval,recno,2,foStrArrayStrOfIndex(video,',',k-1));
       end loop;
    end if;



    resultS:=0;
    commit;
 exception
    when others then
        rollback;
        resultS:=1;
 end poaddeventandmedianew;
/
