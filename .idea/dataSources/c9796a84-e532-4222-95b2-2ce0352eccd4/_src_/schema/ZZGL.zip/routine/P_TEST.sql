CREATE procedure p_test
as

ssys sys_refcursor;
t_Id number;
v_tmp varchar2(200);
CURSOR cur_emp IS select a.f_id,a.f_hou_id
  from T_PSN_RESIDENT t
  left join t_psn_house a on t.f_houseid=a.f_hou_id
 where f_houseid is not null;
row_emp cur_emp%ROWTYPE;
begin
 
 OPEN cur_emp;
FETCH cur_emp INTO row_emp;
WHILE cur_emp%FOUND
LOOP
  
   update T_PSN_RESIDENT s set s.f_houseid = row_emp.f_id where s.f_houseid=row_emp.f_hou_id;
   FETCH cur_emp INTO row_emp;
   commit;
 end loop; 
 close cur_emp;
end ;
/
