CREATE procedure POUPDATEIDCARD(oldcard         in varchar2, --旧的身份证号码
                                           newcard         in varchar2, --新的身份证号码
                                           resultS       out integer) as
  /**
  作者：李鹏飞
  功能：更改特殊人群表中的身份证号码
  时间：2016-10-13
  版本：0.1
  返回值：
      0 成功
      1 失败
  */

begin
  update t_psn_lsry t0 set t0.f_persionid=newcard  where t0.f_persionid=oldcard;
  update T_SPEC_COMP_PRISION t1 set t1.f_id_num=newcard  where t1.f_id_num=oldcard;
  update T_SPEC_COMM t2 set t2.f_id_num=newcard where t2.f_id_num=oldcard;
  update T_SPEC_PSYCHOSIS t3 set t3.f_id_num=newcard where t3.f_id_num=oldcard;
  update t_spec_drug t4 set t4.f_id_num=newcard where t4.f_id_num=oldcard;
  update t_spec_adis t5 set t5.f_id_num=newcard where t5.f_id_num=oldcard;
  update T_YOUN_EMP_TEEN t6 set t6.f_id_num=newcard where t6.f_id_num=oldcard;

  resultS := 0;
  commit;
exception
  when others then
    rollback;
    resultS := 1;
end POUPDATEIDCARD;
/
