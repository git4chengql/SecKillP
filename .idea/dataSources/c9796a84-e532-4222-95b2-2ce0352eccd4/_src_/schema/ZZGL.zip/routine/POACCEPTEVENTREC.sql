CREATE procedure poAcceptEventRec(recName        in varchar2, --案卷名称
                                             eventDate      in varchar2, --事件发生时间
                                             eventSite      in varchar2, --发生地
                                             eventLevel     in varchar2, --事件级别
                                             eventType      in integer, -- 案(事)件类型
                                             eventDesc      in varchar2, --简述 
                                             eventAddress   in varchar2, --详细地址
                                             gridid         in number, --所属网格
                                             eventPersonNum in integer, --涉事人数
                                             eventUnit      in varchar2, --涉事单位
                                             mainPsnCard    in varchar2, --当事人证件号码
                                             mainPsnId      in varchar2, --当事人证件代码
                                             mainPsnName    in varchar2, --当事人姓名
                                             mainPsnTel     in varchar2, --当事人电话
                                             mainPsnAdd     in varchar2, --当事人居住地
                                             handtime       in varchar2, --化解时限
                                             med            in varchar2, --化解方式
                                             medorg         in varchar2, --化解组织
                                             mednm          in varchar2, --化解责任人姓名
                                             medtel         in varchar2, --化解责任人联系方式
                                             medsta         in number, --化解是否成功，成功：1 失败：0
                                             medcase        in varchar2, --化解情况
                                             appdate        in varchar2, --考评日期yyyy-mm-dd
                                             evaopi         in varchar2, --考评意见
                                             unit           in varchar2, --涉及单位
                                             sex            in varchar2, --主要当事人性别
                                             nation         in varchar2, --主要当事人民族
                                             edu            in varchar2, --主要当事人学历 
                                             persontype     in varchar2, --主要当事人人员类别 
                                             x              in number, --经度
                                             y              in number, --纬度
                                             casenat        in varchar2, --案(事)件性质
                                             pricode        in varchar2, --主犯(嫌疑人)证件代码
                                             prinum         in varchar2, --主犯(嫌疑人)证件号码
                                             priname        in varchar2, --主犯(嫌疑人)姓名
                                             status         in number, --是否破案
                                             crinum         in number, --作案人数
                                             larnum         in number, --在逃人数
                                             arrnum         in number, --抓捕人数
                                             casedet        in varchar2, --案件侦破情况    
                                             fresource      in number, --0  网格员上报  1 群众举报  2 其他（暂定）
                                             resourcer      in number, --F_REPORTER
                                             activestatus   in number, --0 待受理  1 已受理
                                             prostatus      in number, --办理状态
                                             bigtypeid      in number, --大类id
                                             bigtypename    in varchar2, --大类名称
                                             smalltypeid    in number, --小类id
                                             smalltypename  in varchar2, --小类名称
                                             resultS        out integer) as
 -- nowtime      date;
  eventtime    t_wf_Node_Dic.f_acceptlimited%type;
  flimitedtime date;
  recNo varchar2(13);
  /**
  作者：程清雷 
  功能：受理事件
  时间：2016-03-16
  版本：0.1
  返回值：
      0 成功
      1 失败
  */

begin
  recNo:=fogetrecno;
  select t.f_acceptlimited
    into eventtime
    from t_wf_Node_Dic t
   where t.f_nodeid = 1;
  select sysdate + (eventtime / 24) into flimitedtime from dual;
  insert into t_base_event
    (F_EVT_NAME,
     f_evt_date,
     f_evt_site,
     f_evt_level,
     f_evt_type,
     f_evt_description,
     f_evt_address,
     f_gridid,
     f_involved_num,
     f_involved_unit,
     f_mainpsnid,
     f_mainpsnidnum,
     f_name,
     f_tel,
     f_address,
     f_hand_time,
     f_med,
     f_med_org,
     f_med_nm,
     f_med_tel,
     f_med_sta,
     f_med_case,
     f_app_date,
     f_eva_opi,
     f_unit,
     f_sex,
     f_nation,
     f_edu,
     f_persontype,
     f_x,
     f_y,
     f_case_nat,
     F_PRI_CODE,
     f_pri_num,
     f_pri_name,
     f_status,
     f_cri_num,
     f_lar_num,
     f_arr_num,
     f_case_det,
     f_resource,
     f_reporter,
     f_evt_no,
     f_active_status,
     f_pro_status,
     f_limited_time,
     f_bigtype_id,
     f_bigtype_name,
     f_smalltype_id,
     f_smalltype_name)
  values
    (recName,
     eventDate,
     eventSite,
     eventLevel,
     eventType,
     eventDesc,
     eventAddress,
     gridid,
     eventPersonNum,
     eventUnit,
     mainPsnCard,
     mainPsnId,
     mainPsnName,
     mainPsnTel,
     mainPsnAdd,
     handtime,
     med,
     medorg,
     mednm,
     medtel,
     medsta,
     medcase,
     appdate,
     evaopi,
     unit,
     sex,
     nation,
     edu,
     persontype,
     x,
     y,
     casenat,
     pricode,
     prinum,
     priname,
     status,
     crinum,
     larnum,
     arrnum,
     casedet,
     fresource,
     resourcer,
     recNo,
     activestatus,
     prostatus,
     flimitedtime,
     bigtypeid,
     bigtypename,
     smalltypeid,
     smalltypename);
  --1.获得开始节点受理时限等信息
  --2.插入t_Base_Event
  --3.插入活动表 toRecAct

  resultS := 0;
  commit;
exception
  when others then
    resultS := 1;
    rollback;
end poAcceptEventRec;
/
