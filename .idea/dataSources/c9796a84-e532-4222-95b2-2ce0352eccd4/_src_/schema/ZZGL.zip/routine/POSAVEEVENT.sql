CREATE procedure POSAVEEVENT(
            f_evet_no in varchar2,--案卷编号
            f_acceptedid in number,--处理人
            f_nodeid in number,--节点id
            f_state in varchar2,--状态
            fid in number,--t_base_event 表的主键
            f_feedbck in varchar2,--受理意见
            resultS out integer
              )
as
  /**
作者：李鹏飞
功能：实现受理功能
向T_Rec_ACT表插入一条记录,并且更新 t_base_event 表的f_pro_status为1
时间：2016-03-21
版本：0.1
返回值：
  0 成功
  1 失败
修改：
   修改人：程清雷
   内容：修改活动表记录
   版本：0.2
   时间：2016-03-31
*/
f_accepteddate date;
iResult integer;
f_completiondate date;
isResu integer;
act_Id number;
node_Id number;
humanId number;
overHours number(4,2);
begin
  iResult := foGetComplateDate(sysdate,f_accepteddate);
  isResu := foGetComplateDate(sysdate,f_completiondate);
  humanId:= f_acceptedid;
  node_Id:= f_nodeid;
  --修改 by 程清雷
  --更新操作人
  select nvl(F_Act_Id,-1) into act_Id from t_Base_Event where F_Id = fid;
  
  if act_Id <> -1 then
    update t_Rec_Act m 
      set m.F_ACCEPTEDID = humanId,
          m.F_ACCEPTEDDATE = sysdate,
          m.F_FEEDBACK = f_feedbck,
          m.F_STATE = f_state
     where F_Id = act_Id;
  end if;
  
  --查询当前节点处理时限
  select n.F_COMPLIMITED into overHours  from t_Wf_Node_Dic n where n.f_nodeid = node_Id and n.F_PROCESSID = 100;
  
  --插入派遣活动表，记录派遣动作是否超期
  insert into T_Rec_ACT(F_EVT_NO,F_ACCEPTEDID,F_NODEID,F_STATE,f_Overdate)
                 values(f_evet_no,humanId,f_nodeid,f_state*-1,sysdate+(overHours/24));
  
  select F_NEXTNODEID into node_Id from t_Wf_Node_Dic where F_NODEID = 1 and F_PROCESSID = 100;
  
  select max(F_Id) into act_Id  from t_Rec_Act m where F_Evt_No = f_evet_no; 
  
  update t_base_event  t  
     set t.f_pro_status=1,F_Node_Id = node_Id,t.F_ACTIVE_STATUS = f_state,F_ACT_ID = act_Id
         where t.f_id=fid;
         resultS:=0;
         commit;
  exception
     when others then
         rollback;
         resultS:=1;
 end POSAVEEVENT;
/
