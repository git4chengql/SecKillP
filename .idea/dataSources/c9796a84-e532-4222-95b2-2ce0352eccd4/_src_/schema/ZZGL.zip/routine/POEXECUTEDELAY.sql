CREATE procedure PoExecuteDelay(recNo         in varchar2, --案卷编号
                                    isAgree       in number,--是否同意 0 同意 1 不同意
                                    humanId       in number, --操作人
                                    feedback      in varchar2,--延期意见
                                    factivestatus  in integer,--延期状态，用于更新t_base_event表中的状态
                                    resultS       out integer) as
/*
   作者：程清雷
   时间：2016-04-28
   功能：延期操作
   
   李鹏飞修改
   把t_base-event表中的状态更改为延期
 */

 actId integer;
 delayTime number;
 --overDate date;
begin
   select F_Act_Id into actId from t_Base_Event where F_Evt_No = recNo;

   --如果同意则需更新超期时间
   if isAgree = 0 then
     select to_number(f_time) into delayTime from toRecOverDelay where F_Ajbh = recNo;
   end if;

   update t_Rec_Act set F_ACCEPTEDID = humanId,F_ACCEPTEDDATE = sysdate,F_FEEDBACK = feedback where F_Id = actId;
   --更新t_base_event表中的状态
  update t_base_event t  set t.f_active_status=factivestatus where t.f_evt_no=recNo;

   resultS:=0;
   
   exception
     when others then
      resultS:=1;
  
end PoExecuteDelay;
/
