CREATE procedure poinitkeyteens(
                              resultS out integer
                             )
  is
  num number(1);
  dropsql varchar2(500);
  execsql varchar2(4000);
  begin
  --第一个开始
  select count(*) into num from  all_tables where table_name like 'T_STATE_KEYTEENS';
  if num >0 then
     dropsql:='delete from T_STATE_KEYTEENS';
     execute immediate dropsql;
  end if;
  execsql:='insert into t_state_keyteens b(b.f_area,b.f_count,b.f_peonum,b.f_bfb,b.f_jyjz,b.f_sxyd,b.f_knbf,b.f_xlga,b.f_man,b.f_woman,b.f_yjs,b.f_dxbk,b.f_dz,b.f_gz,b.f_cz,b.f_xz,b.f_qt,b.f_xyfourteen,b.f_middelage,b.f_higerage,b.f_dsrjt,b.f_dqjt,b.f_ldjt,b.f_edulower,b.f_badreal,b.f_jtcybtxwd,b.f_qt_house,b.f_d14x16) '
            ||'select a.f_grid_nm f_area,s.f_count,s.f_peonum,round((f_peonum/f_count)*100,2) f_bfb,s.f_jyjz,s.f_sxyd,s.f_knbf,s.f_xlga,s.f_man,s.f_woman,s.f_yjs,s.f_dxbk,s.f_dz,s.f_gz,s.f_cz,s.f_xz,s.f_qt,s.f_xyfourteen,s.f_middelage,s.f_higerage,s.f_dsrjt,s.f_dqjt,s.f_ldjt,s.f_edulower,s.f_badreal,s.f_jtcybtxwd,s.f_qt_house,s.f_d14x16 from'
            ||'(select t.F_GRIDID,count(t.f_id) f_count,COUNT(CASE WHEN t.F_IF_CRIME=1 THEN 1 END) f_peonum,'
            ||'COUNT(CASE WHEN t.f_help_way=''299'' THEN 1 END) f_jyjz,'
            ||'COUNT(CASE WHEN t.f_help_way=''300'' THEN 1 END) f_sxyd,'
            ||'COUNT(CASE WHEN t.f_help_way=''301'' THEN 1 END) f_knbf,'
            ||'COUNT(CASE WHEN t.f_help_way=''302'' THEN 1 END) f_xlga,'
            ||'COUNT(CASE WHEN t.f_sex=''585'' THEN 1 END) f_man,'
            ||'COUNT(CASE WHEN t.f_sex=''586'' THEN 1 END) f_woman,'
            ||'COUNT(CASE WHEN (to_number(t.f_edu)>663 and to_number(t.f_edu)<670) or to_number(t.f_edu)=660 THEN 1 END) f_yjs,'
            ||'COUNT(CASE WHEN to_number(t.f_edu)>669 and to_number(t.f_edu)<675 THEN 1 END) f_dxbk,'
            ||'COUNT(CASE WHEN to_number(t.f_edu)>674 and to_number(t.f_edu)<679 THEN 1 END) f_dz,'
            ||'COUNT(CASE WHEN (to_number(t.f_edu)>678 and to_number(t.f_edu)<689) or (to_number(t.f_edu)>689 and to_number(t.f_edu)<694)  or (to_number(t.f_edu)>694 and to_number(t.f_edu)<698) THEN 1 END) f_gz,'
            ||'COUNT(CASE WHEN to_number(t.f_edu)=10654  THEN 1 END) f_cz,'
            ||'COUNT(CASE WHEN to_number(t.f_edu)=10655  THEN 1 END) f_xz,'
            ||'COUNT(CASE WHEN (to_number(t.f_edu)>660 and to_number(t.f_edu)<664) or to_number(t.f_edu)=689 or to_number(t.f_edu)=694 THEN 1 END) f_qt,'
            ||'COUNT(CASE WHEN FLOOR(MONTHS_BETWEEN(SYSDATE,to_date(t.f_birt,''yyyy-mm-dd''))/12)<14 THEN 1 END) f_xyfourteen,'
            ||'COUNT(CASE WHEN FLOOR(MONTHS_BETWEEN(SYSDATE,to_date(t.f_birt,''yyyy-mm-dd''))/12) between 14 and 15 THEN 1 END) f_d14x16,'
            ||'COUNT(CASE WHEN FLOOR(MONTHS_BETWEEN(SYSDATE,to_date(t.f_birt,''yyyy-mm-dd''))/12) between 16 and 17 THEN 1 END) f_middelage,'
            ||'COUNT(CASE WHEN FLOOR(MONTHS_BETWEEN(SYSDATE,to_date(t.f_birt,''yyyy-mm-dd''))/12) between 18 and 25 THEN 1 END) f_higerage,'
            ||'COUNT(CASE WHEN to_number(t.f_fami_stat)=304  THEN 1 END) f_dsrjt,'
            ||'COUNT(CASE WHEN to_number(t.f_fami_stat)=305  THEN 1 END) f_dqjt,'
            ||'COUNT(CASE WHEN to_number(t.f_fami_stat)=306  THEN 1 END) f_ldjt,'
            ||'COUNT(CASE WHEN to_number(t.f_fami_stat)=307  THEN 1 END) f_edulower,'
            ||'COUNT(CASE WHEN to_number(t.f_fami_stat)=308  THEN 1 END) f_badreal,'
            ||'COUNT(CASE WHEN to_number(t.f_fami_stat)=309  THEN 1 END) f_jtcybtxwd,'
            ||'COUNT(CASE WHEN to_number(t.f_fami_stat)=310  THEN 1 END) f_qt_house '
            ||'from t_youn_emp_teen t group by t.F_GRIDID) s '
            ||'left join t_base_grid a on a.f_id=s.f_gridid';
  execute immediate execsql;
  --第一个结束

    resultS:=0;
    commit;
 exception
    when others then
        dbms_output.put_line(SQLERRM(SQLCODE));
        rollback;
        resultS:=1;
 end poinitkeyteens;
/
