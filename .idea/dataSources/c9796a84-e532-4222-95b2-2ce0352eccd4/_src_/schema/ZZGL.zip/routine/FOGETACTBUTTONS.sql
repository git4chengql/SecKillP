CREATE function foGetActButtons(role_Id in integer,staus_Id in integer,rs out sys_refcursor)
return integer as
/**
  功能：获取角色不同状态下的按钮权限
  作者：程清雷
  时间：2016-03-20
  参数：
      roleId 角色标识
      stausId 状态标识
   返回值：
      0 成功
      1 失败
 */


begin
  open rs for
    select a.stausid
  from t_Wf_Staus_Act a
 where a.stausid in (select ActId from t_Wf_Role_Act where roleId = role_Id)
   and actid = staus_Id;
        

   return 0;
   exception
      when others then
      return 1;
end;
/
