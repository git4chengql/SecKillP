CREATE function foGetComplateDate(date1 in Date,rs_Date out Date) return integer

as

begin
  rs_Date:=date1;
  return 0;
end;
/
