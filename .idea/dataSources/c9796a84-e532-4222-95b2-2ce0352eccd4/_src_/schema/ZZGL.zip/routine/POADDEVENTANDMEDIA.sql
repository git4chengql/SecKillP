CREATE procedure poaddeventandmedia(
                              img in   varchar2,
                              song in   varchar2,
                              video in   varchar2,
                              f_evt_description in varchar2,
                              f_bigtype_id in number,
                              f_smalltype_id in number,
                              f_bigtype_name in  varchar2,
                              f_smalltype_name in  varchar2,
                              x in number,
                              y in number,
                              f_humanid in number,
                              f_evt_name in  varchar2,
                              f_gisid in number,
                              f_gridid in number,
                              resultS out integer
                             )
  is
     recno VARCHAR2(20);
     evt_type NUMBER(10);
     next_Node NUMBER;
     act_Id NUMBER;
     overHour number;
  begin

    recno := foGetRecNo();

    select e.f_type into evt_type from tcdiceventtype e where e.typeid=f_bigtype_id;
    insert into T_BASE_EVENT t( t.f_id,t.f_evt_description,t.f_evt_no,t.f_bigtype_id,t.f_smalltype_id,t.f_x,t.f_y,t.F_REPORTER,t.f_gisid,t.f_bigtype_name,t.f_smalltype_name,t.F_RESOURCE,t.f_gridid,t.F_NODE_ID,F_EVT_TYPE,t.f_evt_name)

     values(seq_base_event.nextval,f_evt_description,recno,f_bigtype_id,f_smalltype_id,x,y,f_humanid,f_gisid,f_bigtype_name,f_smalltype_name,0,f_gridid,2,evt_type,f_evt_name);
    if img is not null then
        for i in 1..foStrArrayLength(img,',') loop
            insert into  T_REC_MEDIA t(t.id,t.recid,t.mediatype,t.medianame)
            values(seq_rec_medis.nextval,recno,0,foStrArrayStrOfIndex(img,',',i-1));
        end loop;
    end if;
    if song is not null then
       for j in 1..foStrArrayLength(song,',') loop
           insert into  T_REC_MEDIA t(t.id,t.recid,t.mediatype,t.medianame)
            values(seq_rec_medis.nextval,recno,1,foStrArrayStrOfIndex(song,',',j-1));

        end loop;
    end if;
    if video is not null then
       for k in 1..foStrArrayLength(video,',') loop
            insert into  T_REC_MEDIA t(t.id,t.recid,t.mediatype,t.medianame)
             values(seq_rec_medis.nextval,recno,2,foStrArrayStrOfIndex(video,',',k-1));
       end loop;
    end if;
    
    --增加活动表 by 程清雷
    
    --获取上报后的下一节点
    select n.f_nextnodeid into next_Node from t_Wf_Node_Dic n where n.f_nodeid = 1 and n.F_PROCESSID = 100;
    
    --插入上报动作信息
    insert into t_Rec_Act m (m.F_Evt_No,F_AcceptedId,F_NodeId,F_State,F_CompletionDate,F_ACCEPTEDDATE,F_OVERDATE)values(recno,f_humanid,1,1,sysdate,sysdate,sysdate);
    
    --或得下一节点的超期时限
    select d.f_complimited into overHour from t_Wf_Node_Dic d where d.f_nodeid = next_Node and d.F_PROCESSID = 100;
    
    --插入下一节点相关信息
    insert into t_Rec_Act a (a.F_Evt_No,a.F_ACCEPTEDID,a.F_NodeId,a.F_State,F_OVERDATE)values(recno,'',next_Node,2,sysdate+(overHour/24));
  
    --记录最新活动标识
    select max(F_Id) into act_Id from t_Rec_Act where F_Evt_No = recno;
    
    --更新主表
    update t_Base_Event set F_Act_Id = nvl(act_Id,-1) where F_Evt_No = recno;
    
    resultS:=0;
    commit;
 exception
    when others then
        rollback;
        resultS:=1;
 end poaddeventandmedia;
/
