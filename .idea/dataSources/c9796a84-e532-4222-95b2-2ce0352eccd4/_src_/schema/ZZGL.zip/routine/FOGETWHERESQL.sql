CREATE function FoGetWhereSQL(i_humanId in integer,roleId in integer,whereOut out varchar) return integer
as

/**
 功能：根据用户获取可以访问的节点
 时间：2016-04-06
 作者：程清雷
 参数说明：
    humanId 用户标识
    roleId 角色
    whereOut where语句
    李鹏飞修改
    修改时间：2016-05-03
    修改位置：最后 sql部门 加上了延期的状态
     or F_ACTIVE_STATUS = 5
 */
 resultStr varchar2(500);
 regionId integer;
 i_unitId integer;
 sys_Nodes sys_refcursor;
 node_Id integer;
 nodes varchar2(200);
begin

  resultStr:='where ( 1=1';
  nodes:='(';
  select nvl(h.regionid,-1),nvl(h.unitid,-1) into regionId,i_unitId from tcHuman h where h.humanid = i_humanId;
 --1、先判断角色，是否根据所属网格过滤数据;暂：网格员过滤
  if roleId = 1  then
     resultStr:=' and F_GRIDID = '||regionId;--暂用GridId
  end if;
 --2、然后根据配置获取节点
  open sys_Nodes for select nodeId from t_Wf_Nodeunit n where UnitId = i_unitId;
 --3、拼凑sql
    loop
     fetch sys_Nodes into node_Id;
      exit when sys_Nodes%NOTFOUND;
      if nodes != '(' then
       nodes:=nodes||','||node_Id;
      else
       nodes:=nodes||node_Id;
      end if;
    end loop;
    nodes:=nodes||')';
   close sys_Nodes;
  
    if nodes !='()' then
      whereOut := resultStr||' and F_NODE_ID in '||nodes;
    else
      whereOut := resultStr;
    end if;
 
 
  
  --4、如果案卷所处阶段已有人受理，则只有该受理人员能看到此案卷
  if roleId = 2 then
   whereOut:=whereOut||' and (f_acceptedid = '||i_humanId||' or f_acceptedid is null)';
  end if;
  --5、过滤作废、结案 案卷
  whereOut:=whereOut||' and (F_ACTIVE_STATUS !=-1 and F_ACTIVE_STATUS != 7)';
  
  whereOut:=whereOut||')';
  
  --如果是派遣中心角色 将申请延期的案卷包含进去，暂没加是不是此人派遣的案卷的过滤
  if roleId = 2 then
    whereOut:=whereOut||' or F_ACTIVE_STATUS = 4 or F_ACTIVE_STATUS = 5';
  end if;
  

  return 0;
 
 exception 
    
   when others then
   dbms_output.put_line(sqlerrm);
     return 1;
end;
/
