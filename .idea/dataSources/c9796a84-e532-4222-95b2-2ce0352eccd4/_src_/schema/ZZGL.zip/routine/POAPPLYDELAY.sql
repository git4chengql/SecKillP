CREATE procedure PoApplyDelay(fajbh         in varchar2, --案卷编号
                                           ftype         in number, --类型，督办或者申请延期
                                           ftime         in varchar2, --所需时间
                                           fbz           in varchar2, --备注
                                           feventid      in number, --事件的id
                                           factivestatus in number, --活动状态
                                           humanId       in number,--操作人
                                           resultS       out integer) as
  /**
  作者：李鹏飞
  功能：申请延期
  时间：2016-03-21
  版本：0.1
  返回值：
      0 成功
      1 失败
      
   修改：
       程清雷 2016-4-28
       完善活动表
  */
  
  actId integer;
  nodeId integer;
begin
  insert into toRecOverDelay
    (F_AJBH, F_TYPE, F_TIME, F_BZ)
  values
    (fajbh, ftype, ftime, fbz);
    
  update t_Base_Event t set t.f_active_status = factivestatus where t.f_id = feventid;
  
  select  F_Act_Id,F_NODE_ID into actId,nodeId  from t_Base_Event where F_Evt_No = fajbh;
  
  --更新活动记录：将最新的活动记录的accepttime时间更新
  update t_Rec_Act set F_ACCEPTEDDATE = sysdate ,F_State =factivestatus ,F_FeedBack = fbz,F_ACCEPTEDID = humanId  where F_Id = actId;
  
  --插入新记录，待派遣中心将申请结果打回
  insert into t_Rec_Act(F_EVT_NO,F_NODEID,F_STATE)values(fajbh,nodeId,5);
  
  --更新事件主表的Act_ID
  select max(F_Id) into actId from t_Rec_Act where F_EVT_NO = fajbh;
  
  update t_Base_Event set F_ACT_ID = actId where F_Evt_No = fajbh;
  
  resultS := 0;
  commit;
exception
  when others then
    rollback;
    resultS := 1;
end PoApplyDelay;
/
