CREATE function foGetGridSQL(i_humanId in integer,
                                        fregionid in integer,
                                        whereSQL  out varchar)
  return integer as

  /**
  功能：根据用户获取可以访问的网格
  时间：2016-04-06
  作者：程清雷
  参数说明：
     humanId 用户标识
     roleId 角色
     whereSQL where语句
  */
  resultStr varchar2(500);
  grids     varchar2(2000);
  gridId    integer;
  sys_Grids sys_refcursor;
begin

  resultStr := ' and F_GRIDID in (';
  grids     := '';

  open sys_Grids for
    select gridId from t_Human_Grid h where h.humanid = i_humanId and gridId in (select f_id from t_base_grid  t  where t.f_areaid in
    (select t.fid  from t_base_area t  start with fid=fregionid
               connect by prior fid=parentid));

  loop
    fetch sys_Grids into gridId;
    exit when sys_Grids%NOTFOUND;
    if grids is not null then
      grids := grids || ',' || gridId;
    else
      grids := grids || gridId;
    end if;
  end loop;
  grids := grids || ')';
  
  close sys_Grids;

  if grids = ')' then
    whereSQL := resultStr || ''''')';
  else
    whereSQL := resultStr || grids;
  end if;

  return 0;

exception
  when others then
    dbms_output.put_line(sqlerrm);
    return 1;
end;
/
