CREATE procedure POTorecact(
            f_evet_no in varchar2,--案卷编号
            f_acceptedid in number,--处理人
            f_nodeid in number,--节点id
            f_state in varchar2,--状态
            f_feedback in varchar2,--反馈意见
            f_accepteddate in date,--受理时间
            f_completiondate in  date,--完成时间
            resultS out integer
              )
as
  /**
作者：李鹏飞
功能：向T_WF_ACT业务流程表插入一条记录
时间：2016-03-21
版本：0.1
返回值：
  0 成功
  1 失败
*/
begin
  insert into T_Rec_ACT(F_EVT_NO,F_ACCEPTEDID,F_NODEID,F_STATE,
  F_FEEDBACK,F_ACCEPTEDDATE,F_COMPLETIONDATE)
  values(f_evet_no,f_acceptedid,f_nodeid,f_state,
  f_feedback,f_accepteddate,f_completiondate);

         resultS:=0;
         commit;
         exception
         when others then
         rollback;
         resultS:=1;
       end POTorecact;
/
