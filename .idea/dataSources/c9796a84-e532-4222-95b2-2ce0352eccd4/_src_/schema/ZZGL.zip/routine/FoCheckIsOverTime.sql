CREATE FUNCTION "FoCheckIsOverTime"
("recDate" IN DATE) RETURN NUMBER AS
result number;
/**
  功能：检测是否超时
  返回值：
     0 未超时
     1 即将到期
     2 超期
  待完善：
     延期的时间待加入检测
 */
BEGIN
  select (case when "recDate">"SYSDATE"  then 0 
               when "recDate"-1>=sysdate then 1 
               when "recDate"<"SYSDATE" then 2 end) 
     into result 
   from dual;
  return result;
  EXCEPTION
     when others then 
       result:=0;
    return result;
END;
/
