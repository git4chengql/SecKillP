CREATE procedure poinitchartdata(
                              resultS out integer
                             )
  is
  num number(1);
  dropsql varchar2(500);
  execsql varchar2(1000);
  begin
  --第一个开始
  select count(*) into num from  all_tables where table_name like 'T_SEX_NUM';
  if num >0 then
     dropsql:='delete from T_SEX_NUM';
     execute immediate dropsql;
  end if;
  execsql:='insert into t_sex_num r(r.f_sex,r.num) select t.f_sex,count(t.f_sex) num  from t_psn_resident t group by t.f_sex';
  execute immediate execsql;
  --第一个结束
  --第二个开始
  select count(*) into num from  all_tables where table_name like 'T_SEX_NUM_GRID';
  if num >0 then
     dropsql:='delete from T_SEX_NUM_GRID';
     execute immediate dropsql;
  end if;
  execsql:='insert into T_SEX_NUM_GRID r(r.f_gridid,r.f_sex,r.num)select t.f_gridid,t.f_sex,count(t.f_sex) num  from t_psn_resident t group by t.f_sex,t.f_gridid';
  execute immediate execsql;
  --第二个结束
  --第三个开始
  select count(*) into num from  all_tables where table_name like 'T_AGE_NUM';
  if num >0 then
     dropsql:='delete from T_AGE_NUM';
     execute immediate dropsql;
  end if;
  execsql:='insert into t_age_num r(r.age010,r.age1120,r.age2130,r.age3140,r.age4150,r.age5160,r.age61) select COUNT(CASE WHEN age<=10 THEN 1 END) age010,COUNT(CASE WHEN age between 11 and 20 THEN 1 END) age1120,COUNT(CASE WHEN age between 21 and 30 THEN 1 END) age2130,COUNT(CASE WHEN age between 31 and 40 THEN 1 END) age3140,COUNT(CASE WHEN age between 41 and 50 THEN 1 END) age4150,COUNT(CASE WHEN age between 51 and 60 THEN 1 END) age5160,COUNT(CASE WHEN age>60 THEN 1 END) age61 from(select FLOOR(MONTHS_BETWEEN(SYSDATE,to_date(t.f_birthday,''yyyy-mm-dd''))/12) age from t_psn_resident t)';
  execute immediate execsql;
  --第三个结束
  --第四个开始
  select count(*) into num from  all_tables where table_name like 'T_AGE_NUM_GRID';
  if num >0 then
     dropsql:='delete from T_AGE_NUM_GRID';
     execute immediate dropsql;
  end if;
  execsql:='insert into t_age_num_grid r(r.age010,r.age1120,r.age2130,r.age3140,r.age4150,r.age5160,r.age61,r.f_gridid) select COUNT(CASE WHEN age<=10 THEN 1 END) age010,COUNT(CASE WHEN age between 11 and 20 THEN 1 END) age1120,COUNT(CASE WHEN age between 21 and 30 THEN 1 END) age2130,COUNT(CASE WHEN age between 31 and 40 THEN 1 END) age3140,COUNT(CASE WHEN age between 41 and 50 THEN 1 END) age4150,COUNT(CASE WHEN age between 51 and 60 THEN 1 END) age5160,COUNT(CASE WHEN age>60 THEN 1 END) age61,s.f_gridid from(select FLOOR(MONTHS_BETWEEN(SYSDATE,to_date(t.f_birthday,''yyyy-mm-dd''))/12) age,t.f_gridid from t_psn_resident t) s  group by s.f_gridid';
  execute immediate execsql;
  --第四个结束
  --第五个开始
  select count(*) into num from  all_tables where table_name like 'T_NATION_NUM';
  if num >0 then
     dropsql:='delete from T_NATION_NUM';
     execute immediate dropsql;
  end if;
  execsql:='insert into t_nation_num s(s.f_name,s.num) select a.F_NAME,r.num from(select t.f_nation,count(t.f_nation) num from t_psn_resident t group by t.f_nation) r left join v_base_nation a on r.f_nation=a.F_ID ';
  execute immediate execsql;
  --第五个结束
  --第六个开始
  select count(*) into num from  all_tables where table_name like 'T_NATION_NUM_GRID';
  if num >0 then
     dropsql:='delete from T_NATION_NUM_GRID';
     execute immediate dropsql;
  end if;
  execsql:='insert into t_nation_num_grid s(s.f_name,s.num,s.f_gridid) select a.F_NAME,r.num,r.f_gridid from(select t.f_nation,count(t.f_nation) num,t.f_gridid from t_psn_resident t group by t.f_nation,t.f_gridid) r left join v_base_nation a on r.f_nation=a.F_ID ';
  execute immediate execsql;
  --第六个结束
  --第七个开始
  select count(*) into num from  all_tables where table_name like 'T_RESID_FLOAT_NUM';
  if num >0 then
     dropsql:='delete from T_RESID_FLOAT_NUM';
     execute immediate dropsql;
  end if;
  execsql:='insert into t_resid_float_num r(r.f_floatflag,r.num) select t.f_floatflag,count(t.f_floatflag) num from t_psn_resident t group by t.f_floatflag';
  execute immediate execsql;
  --第七个结束
  --第八个开始
  select count(*) into num from  all_tables where table_name like 'T_RESID_FLOAT_NUM_GRID';
  if num >0 then
     dropsql:='delete from T_RESID_FLOAT_NUM_GRID';
     execute immediate dropsql;
  end if;
  execsql:='insert into t_resid_float_num_grid r(r.f_floatflag,r.num,r.f_gridid) select t.f_floatflag,count(t.f_floatflag) num,t.f_gridid from t_psn_resident t group by t.f_floatflag,t.f_gridid';
  execute immediate execsql;
  --第八个结束
  --第九个开始
  select count(*) into num from  all_tables where table_name like 'T_LSRY_NUM';
  if num >0 then
     dropsql:='delete from T_LSRY_NUM';
     execute immediate dropsql;
  end if;
  execsql:='insert into T_LSRY_NUM select count(t.f_id) num from t_psn_lsry t';
  execute immediate execsql;
  --第九个结束
  --第十个开始
  select count(*) into num from  all_tables where table_name like 'T_LSRY_NUM_GRID';
  if num >0 then
     dropsql:='delete from T_LSRY_NUM_GRID';
     execute immediate dropsql;
  end if;
  execsql:='insert into T_LSRY_NUM_GRID r(r.num,r.F_GRIDID) select count(t.f_id)num,t.f_gridid from t_psn_lsry t group by t.f_gridid';
  execute immediate execsql;
  --第十个结束
  --第十一个开始
  select count(*) into num from  all_tables where table_name like 'T_ZDQSN_NUM';
  if num >0 then
     dropsql:='delete from T_ZDQSN_NUM';
     execute immediate dropsql;
  end if;
  execsql:='insert into t_zdqsn_num select count(t.f_id) num from t_youn_emp_teen t';
  execute immediate execsql;
  --第十一个结束
  --第十二个开始
  select count(*) into num from  all_tables where table_name like 'T_ZDQSN_NUM_GRID';
  if num >0 then
     dropsql:='delete from T_ZDQSN_NUM_GRID';
     execute immediate dropsql;
  end if;
  execsql:='insert into t_zdqsn_num_grid r(r.num,r.f_gridid) select count(t.f_id) num,t.f_gridid from t_youn_emp_teen t group by t.f_gridid';
  execute immediate execsql;
  --第十二个结束
    resultS:=0;
    commit;
 exception
    when others then
        rollback;
        resultS:=1;
 end poinitchartdata;
/
