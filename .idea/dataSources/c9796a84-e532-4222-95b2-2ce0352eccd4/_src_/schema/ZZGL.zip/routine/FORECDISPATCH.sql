CREATE function foRecDispatch(humanId in Integer,recNo in varchar2,nextNodeId in Integer,note in varchar2) return integer
as
/**
  功能：案卷派遣--指挥中心往专业部门派遣
  作者：程清雷
  时间：2016-03-20
  参数说明：
     recNo 案卷编号
     humanId 用户标识
     nextNode 下一节点
     note  意见
   返回参数
      0 成功
      1 失败
 */
 act_Id integer;
 actStatus integer;
 limitedTime number(4,2);
 nextNodeName varchar2(200);
begin
  select r.F_ACT_ID into act_Id from t_Base_Event r where r.F_Evt_No = recNo;
  
  select n.F_NODENAME into  nextNodeName from t_Wf_Node_Dic n where n.f_nodeid = nextNodeId;
  
  if nextNodeId not in (6,7) then
    actStatus := 8;
  end if;

  --更新上一活动完成时间
  update t_Rec_Act m set m.F_ACCEPTEDDATE = sysdate,m.F_ACCEPTEDID = humanId,m.f_state = actStatus,m.F_FEEDBACK = '派遣至'||nextNodeName||' '||note  where m.F_Id = act_Id;
  
  --专业部门处理时限
  select w.f_complimited into limitedTime from t_Wf_Node_Dic w where w.f_nodeid = nextNodeId and w.f_processid = 100;
  
  --插入派遣动作相关信息
  insert into t_Rec_Act n(n.F_EVT_NO,n.F_NODEID,n.F_STATE,F_OVERDATE)values(recNo,nextNodeId,actStatus,sysdate+(limitedTime/24));
  
  --更新主表活动主键
  select max(F_Id) into act_Id from t_Rec_Act where F_Evt_No = recNo;
  
  update t_Base_Event e set e.F_ACT_ID = act_Id,e.F_NODE_ID = nextNodeId,e.f_active_status = actStatus where F_Evt_No = recNo;
  
  commit;
  return 0;
  Exception 
     when others then 
     rollback;
     return 1;
end;
/
