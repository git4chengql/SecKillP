CREATE procedure pcReGenerateSeq
as

begin
  EXECUTE IMMEDIATE 'DROP SEQUENCE SEQ_RECNO';
	EXECUTE IMMEDIATE 'CREATE SEQUENCE SEQ_RECNO minvalue 1 maxvalue 999999  start with 1 increment by 1';
end;
/
