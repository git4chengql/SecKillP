CREATE procedure POTWFROLEACT(
                roleid in number,
                actid in number,
                resultS out integer
                    )
as
  /**
作者：李鹏飞
功能：T_WF_ROLE_ACT表中存储角色和案卷状态的关系
时间：2016-03-22
版本：0.1
返回值：
    0 成功
    1 失败
*/
begin
  insert into T_WF_ROLE_ACT (ROLEID, ACTID) values (roleid, actid);
  resultS := 0;
  commit;
  exception when others then rollback;
  resultS := 1;
  end POTWFROLEACT;
/
