CREATE procedure POTWFSTAUSACT(
                statusid in number,
                actid in number,
                resultS out integer
                    )
as
  /**
作者：李鹏飞
功能：T_WF_STAUS_ACT表中存储关系
时间：2016-03-21
版本：0.1
返回值：
    0 成功
    1 失败
*/
begin
  insert into T_WF_STAUS_ACT (STAUSID, ACTID) values (statusid, actid);
  resultS := 0;
  commit;
  exception when others then rollback; 
  resultS := 1; 
  end POTWFSTAUSACT;
/
