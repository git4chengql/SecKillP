CREATE procedure POTWFNODEUNIT(
                nodeid in number,
                unitid in number,
                resultS out integer
                    )
as
  /**
作者：李鹏飞
功能：T_WF_NODEUNIT 流程节点和部门关系表中存数流程id 和部门id
时间：2016-03-28
版本：0.1
返回值：
    0 成功
    1 失败
*/
begin
  insert into T_WF_NODEUNIT (NODEID, UNITID) values (nodeid, unitid);
  resultS := 0;
  commit;
  exception when others then rollback;
  resultS := 1;
  end POTWFNODEUNIT;
/
