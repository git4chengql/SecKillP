CREATE procedure POREACTZFAndJA(factid      in number, --活动表最新活动主键
                                           facceptedid in number, --处理人
                                           feedbck     in varchar2, --反馈意见
                                           fid         in number,--t_base_event 表的主键
                                           factivestatus in number,
                                           resultS     out integer) as
  /**
    活动状态 0正常 1登记 2受理 3 督办 4申请延期 5延期 6核查 7结案 8派遣 -1作废

    作者：李鹏飞
    功能：案卷操作处理,实现作废和结案功能
    时间：2016-04-12
    版本：0.1
    返回值：
      0 成功
      1 失败
  */

begin

  /*
  更新T_Rec_ACT 表
  */
  update T_Rec_ACT a
     set a.f_acceptedid   = facceptedid,
         a.f_feedback     = feedbck,
         a.f_accepteddate = sysdate,
         a.F_State = factivestatus
   where a.f_id = factid;
  /*
  更新t_base_event 表
  */

  update t_base_event t
     set t.f_active_status = factivestatus
   where t.f_id = fid;

  resultS := 0;
  commit;
exception
  when others then
    rollback;
    resultS := 1;
end POREACTZFAndJA;
/
