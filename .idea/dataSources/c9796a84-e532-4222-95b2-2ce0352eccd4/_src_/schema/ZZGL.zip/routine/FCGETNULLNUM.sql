CREATE function         fcGetNullNum(
  sTableName in varchar2,
  sFieldName in varchar2,
  iFromNum in integer := 1
) return integer is
/**
功能：取指定表指定字段从指定序号开始最小可用序号
类别：基础
版本：标准版本
参数：
  sTableName 表名
  sFieldName 字段名
  iFromNum 起始号
返回值：
  可用的最小的号
历史：
2013-10-10 chenql
**/
  Result integer;
  int1 integer;
  sSQL varchar2(2000);
begin
  Result := 0;
  if iFromNum is null then
    int1 := 0;
  else
    int1 := iFromNum ;
  end if;
 /* sSQL := 'select Num+'||TO_CHAR(int1)||' from (select RowNum as Num,a.ID from '|| 
      ' (select distinct '||sFieldName||' as ID from '||sTableName||' where '||sFieldName||
      ' > '||TO_CHAR(int1)||' order by '||sFieldName||
      ' ) a) where ID - Num > '||TO_CHAR(int1)||' and RowNum = 1 ';*/
    sSQL :='select max('||sFieldName||')+1 as ID from '||sTableName;
  begin
    EXECUTE IMMEDIATE sSQL into Result;
  exception
    when others then
    begin
      sSQL := 'select Nvl(Max('||sFieldName||'),'||TO_CHAR(int1)||
         ')+1 from '||sTableName||' where '||sFieldName||
      ' > '||TO_CHAR(int1);  
      EXECUTE IMMEDIATE sSQL into Result;
    end;
  end;
  return Result;
end;
/
