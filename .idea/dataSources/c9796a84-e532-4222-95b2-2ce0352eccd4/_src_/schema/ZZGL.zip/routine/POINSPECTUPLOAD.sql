CREATE procedure poinspectupload(
                              img in   varchar2,
                              song in   varchar2,
                              video in   varchar2,
                              recno in varchar2,
                              states in number,
                              actstatus in number,
                              resultS out integer
                             )
  is

  begin


    if img is not null then
        for i in 1..foStrArrayLength(img,',') loop
            insert into  T_REC_MEDIA t(t.id,t.recid,t.mediatype,t.medianame,t.state)
            values(seq_rec_medis.nextval,recno,0,foStrArrayStrOfIndex(img,',',i-1),states);
        end loop;
    end if;
    if song is not null then
       for j in 1..foStrArrayLength(song,',') loop
           insert into  T_REC_MEDIA t(t.id,t.recid,t.mediatype,t.medianame,t.state)
            values(seq_rec_medis.nextval,recno,1,foStrArrayStrOfIndex(song,',',j-1),states);

        end loop;
    end if;
    if video is not null then
       for k in 1..foStrArrayLength(video,',') loop
            insert into  T_REC_MEDIA t(t.id,t.recid,t.mediatype,t.medianame,t.state)
             values(seq_rec_medis.nextval,recno,2,foStrArrayStrOfIndex(video,',',k-1),states);
       end loop;
    end if;
    update t_ver_task t set t.f_status=1 where t.f_evt_no=recno;
    
     update t_base_event t set t.f_active_status=actstatus where t.f_evt_no=recno;
    resultS:=0;
    commit;
 exception
    when others then
        rollback;
        resultS:=1;
 end poinspectupload;
/
