CREATE procedure poinitspeccomm(
                              resultS out integer
                             )
  is
  num number(1);
  dropsql varchar2(500);
  execsql varchar2(4000);
  begin
  --第一个开始
  select count(*) into num from  all_tables where table_name like 'T_SPEC_COMM';
  if num >0 then
     dropsql:='delete from T_SPEC_COMM';
     execute immediate dropsql;
  end if;
  execsql:='insert into t_state_speccomm s(s.f_area,s.f_num_now,s.f_receivecount,s.f_liftcount,s.f_gz,s.f_hx,s.f_js,s.f_jwzx,s.f_man,s.f_woman,s.f_updz,s.f_highschool,s.f_cz,s.f_wcn,s.f_middelage,s.f_highage,s.f_maxage)'
  ||'select a.f_grid_nm,r.f_num_now,r.f_receivecount,r.f_receivecount-r.f_num_now f_liftcount,r.f_gz,r.f_hx,r.f_js,r.f_jwzx,r.f_man,r.f_woman,r.f_updz,r.f_highschool,r.f_cz,'
  ||'r.f_wcn,r.f_middelage,r.f_highage,r.f_maxage'
  ||'from(select t.f_gridid,count(case when to_date(t.f_rect_end_date,''yyyy-mm-dd'')>to_date(to_char(sysdate,''yyyy-mm-dd''),''yyyy-mm-dd'') then 1 end) f_num_now,'
  ||'count(t.f_id) f_receivecount,'
  ||'count(case when t.f_rect_type=''124'' and to_date(t.f_rect_end_date,''yyyy-mm-dd'')>to_date(to_char(sysdate,''yyyy-mm-dd''),''yyyy-mm-dd'') then 1 end) f_gz,'
  ||'count(case when t.f_rect_type=''125'' and to_date(t.f_rect_end_date,''yyyy-mm-dd'')>to_date(to_char(sysdate,''yyyy-mm-dd''),''yyyy-mm-dd'') then 1 end) f_hx,'
  ||'count(case when t.f_rect_type=''126'' and to_date(t.f_rect_end_date,''yyyy-mm-dd'')>to_date(to_char(sysdate,''yyyy-mm-dd''),''yyyy-mm-dd'') then 1 end) f_js,'
  ||'count(case when t.f_rect_type=''127'' and to_date(t.f_rect_end_date,''yyyy-mm-dd'')>to_date(to_char(sysdate,''yyyy-mm-dd''),''yyyy-mm-dd'') then 1 end) f_jwzx,'
  ||'count(case when t.f_sex=''585'' and to_date(t.f_rect_end_date,''yyyy-mm-dd'')>to_date(to_char(sysdate,''yyyy-mm-dd''),''yyyy-mm-dd'') then 1 end) f_man,'
  ||'count(case when t.f_sex=''586'' and to_date(t.f_rect_end_date,''yyyy-mm-dd'')>to_date(to_char(sysdate,''yyyy-mm-dd''),''yyyy-mm-dd'') then 1 end) f_woman,'
  ||'count(case when to_number(t.f_edu)<679 and to_date(t.f_rect_end_date,''yyyy-mm-dd'')>to_date(to_char(sysdate,''yyyy-mm-dd''),''yyyy-mm-dd'') then 1 end) f_updz,'
  ||'count(case when to_number(t.f_edu)>678 and to_number(t.f_edu)<698 and to_number(t.f_edu)<>689 and to_number(t.f_edu)<>694 and to_date(t.f_rect_end_date,''yyyy-mm-dd'')>to_date(to_char(sysdate,''yyyy-mm-dd''),''yyyy-mm-dd'') then 1 end) f_highschool,'
  ||'count(case when (to_number(t.f_edu)=689 or to_number(t.f_edu)=694 or to_number(t.f_edu)=10654 or to_number(t.f_edu)=10655) and to_date(t.f_rect_end_date,''yyyy-mm-dd'')>to_date(to_char(sysdate,''yyyy-mm-dd''),''yyyy-mm-dd'') then 1 end) f_cz,'
  ||'COUNT(CASE WHEN FLOOR(MONTHS_BETWEEN(SYSDATE,to_date(t.f_birt,''yyyy-mm-dd''))/12)<18 and to_date(t.f_rect_end_date,''yyyy-mm-dd'')>to_date(to_char(sysdate,''yyyy-mm-dd''),''yyyy-mm-dd'') THEN 1 END) f_wcn,'
  ||'COUNT(CASE WHEN FLOOR(MONTHS_BETWEEN(SYSDATE,to_date(t.f_birt,''yyyy-mm-dd''))/12)>17 and FLOOR(MONTHS_BETWEEN(SYSDATE,to_date(t.f_birt,''yyyy-mm-dd''))/12)<45 and to_date(t.f_rect_end_date,''yyyy-mm-dd'')>to_date(to_char(sysdate,''yyyy-mm-dd''),''yyyy-mm-dd'') THEN 1 END) f_middelage,'
  ||'COUNT(CASE WHEN FLOOR(MONTHS_BETWEEN(SYSDATE,to_date(t.f_birt,''yyyy-mm-dd''))/12)>44 and FLOOR(MONTHS_BETWEEN(SYSDATE,to_date(t.f_birt,''yyyy-mm-dd''))/12)<61 and to_date(t.f_rect_end_date,''yyyy-mm-dd'')>to_date(to_char(sysdate,''yyyy-mm-dd''),''yyyy-mm-dd'') THEN 1 END) f_highage,'
  ||'COUNT(CASE WHEN FLOOR(MONTHS_BETWEEN(SYSDATE,to_date(t.f_birt,''yyyy-mm-dd''))/12)>60 and to_date(t.f_rect_end_date,''yyyy-mm-dd'')>to_date(to_char(sysdate,''yyyy-mm-dd''),''yyyy-mm-dd'') THEN 1 END) f_maxage'
  ||'from t_spec_comm t  group by t.f_gridid) r'
  ||'left join t_base_grid a on a.f_id=r.f_gridid';
  execute immediate execsql;
  --第一个结束

    resultS:=0;
    commit;
 exception
    when others then
        dbms_output.put_line(SQLERRM(SQLCODE));
        rollback;
        resultS:=1;
 end poinitspeccomm;
/
