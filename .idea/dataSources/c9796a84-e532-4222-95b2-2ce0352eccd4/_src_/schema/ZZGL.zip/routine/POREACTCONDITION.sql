CREATE procedure POREACTCONDITION(
            f_evt_no in varchar2,--案卷编号
            f_acceptedid in number,--处理人
            f_nodeid in number,--节点id
            f_state in varchar2,--状态
            fid in number,
            factivestatus in number,
            f_feedbck in varchar2,--反馈意见
            resultS out integer
              )
as
  /**
  活动状态 0正常 1登记 2受理 3 督办 4申请延期 5延期 6核查 7结案 8派遣 -1作废
  
  作者：李鹏飞
  功能：案卷操作处理
  时间：2016-03-21
  版本：0.1
  返回值：
    0 成功
    1 失败
*/
f_accepteddate date;
iResult integer;
f_completiondate date;
isResu integer;
factid integer;
begin

  iResult:= foGetComplateDate(sysdate,f_accepteddate);
  isResu:=foGetComplateDate(sysdate,f_completiondate);
  --逻辑有待修改，应分不同阶段处理
  --受理阶段 与其他阶段应区分
  insert into T_Rec_ACT(F_EVT_NO,F_ACCEPTEDID,F_NODEID,F_STATE,F_ACCEPTEDDATE,F_COMPLETIONDATE,F_FEEDBACK)
  values(f_evt_no,f_acceptedid,f_nodeid,f_state,f_accepteddate,f_completiondate,f_feedbck);
  
  select max(f_id) into factid from T_Rec_ACT t  where t.F_EVT_NO=f_evt_no;
  update t_base_event t  
      set t.f_active_status=factivestatus  ,t.f_act_id=factid
  where t.f_id=fid;

  resultS:=0;
  commit;
  exception
     when others then
         rollback;
         resultS:=1;
 end POREACTCONDITION;
/
