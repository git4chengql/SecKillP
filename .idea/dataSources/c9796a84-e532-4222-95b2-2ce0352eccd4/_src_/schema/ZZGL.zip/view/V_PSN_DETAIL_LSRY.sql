CREATE VIEW V_PSN_DETAIL_LSRY AS select t.f_sqjz fsqjzval,--社区矫正人员标志
       t.f_gridid, --所属网格ID
       q.f_grid_nm, --所属网格名称
       t.f_id, --主键
       t.f_id_card, --身份证号
       t.f_name, --姓名
       t.fsexname,--性别
       t.fnationname,--民族
       t.fxzname,--住址
       t.F_PHOTO, --照片
       ------------------------------------状态标识开始------------------------------------------------
       decode(t.f_attention_yn, 1, '重点关注人员', 0, '', '') f_attention_yn, --重点关注人员
       decode(t.f_floatflag, 1, '流动人口', 0, '户籍人口', '户籍人口') f_floatflag, --数据类别
       decode(t.f_lsry, 1, '留守人员', 0, '', '') f_lsry,
       decode(t.f_xmsf, 1, '刑满释放人员', 0, '', '') f_xmsf,
       decode(t.f_sqjz, 1, '社区矫正', 0, '', '') f_sqjz,
       decode(t.f_jsza, 1, '精神障碍', 0, '', '') f_jsza,
       decode(t.f_xdry, 1, '留守人员', 0, '', '') f_xdry,
       decode(t.f_aids, 1, '艾滋人员', 0, '', '') f_aids,
       decode(t.f_zdqsn, 1, '重点青少年', 0, '', '') f_zdqsn,
       ------------------------------------状态标识结束------------------------------------------------
       ------------------------------------留守人员属性开始------------------------------------------------

       r3.f_health,---健康状况id
       r3.f_leftpersoneltype,--留守人员类型id
       r3.f_leftpersonelrelationship,---与留守人员关系id

       ar3.F_NAME fhealthname, -- 健康状况 v_base_health
       F_PERSONALINCOME, --个人年收入
       br3.F_NAME flsrytypename,--留守人员类型   v_base_rearpersonnelty
       F_FAMILYIDNUMBER,---家庭主要人员身份证号码
       F_FAMILYNAME,--家庭主要人员姓名
       F_FAMILYHEALTH,--家庭主要人员健康状况
       cr3.F_NAME flsrgxname,--与留守人关系
       F_FAMILYTELEPHONE,--家庭主要人员联系方式
       F_FAMILYADDRESS,--家庭主要人员工作详址
       F_FAMILYINCOME,--家庭年收入
       F_DIFFICULTIESANDDEMANDS,--困难及诉求
       F_HELPINGSITUATION--帮扶情况

------------------------------------留守人员属性结束------------------------------------------------ */

  from v_psn_resident t
  left join v_base_grid q on t.f_gridid = q.F_ID
  left join T_PSN_LSRY r3 on t.f_id_card = r3.f_persionid --留守人员
  left join v_base_health ar3 on r3.f_health = ar3.F_ID
  left join v_base_rearpersonnelty br3 on r3.F_LEFTPERSONELTYPE = br3.F_ID
  left join v_base_guardianrelation cr3 on r3.F_LEFTPERSONELRELATIONSHIP = cr3.F_ID



 where t.f_visable = 1


/*留守人员视图*/
/
