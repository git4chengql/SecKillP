CREATE VIEW V_EVENT_BIGCASE AS select t.*,a.F_NAME flocalname,b.F_NAME levelname,c.f_name typename,
g.f_grid_nm fgridname
    from t_event_bigcase t
    left join t_base_grid g on t.f_gridid=g.f_id
   left join v_base_regionalism a on t.f_local=a.F_ID
   left join v_base_code b on t.f_level=b.F_ID
   left join v_base_code c on t.f_type=c.F_ID
/
