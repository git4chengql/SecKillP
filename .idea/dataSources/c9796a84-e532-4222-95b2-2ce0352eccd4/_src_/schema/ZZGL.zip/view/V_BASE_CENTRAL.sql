CREATE VIEW V_BASE_CENTRAL AS select t.F_ID,t.F_CENTRAL_NM,t.F_CENTRAL_LVL,t.F_NAME,t.F_PHONE,t.F_UNIT,t.F_CENTRAL_PHONE,t.F_CITY,t.F_ADDRESS,t.F_X,t.F_Y,t.F_CREATDATE,t.F_GRIDID,t.F_VISABLE,t.cityname,
a.F_NAME f_level_name, b.F_NAME f_city_name,
c.f_grid_nm f_gridid_name,
t.f_region,t.f_region_name
from T_BASE_CENTRAL t
left join v_base_level  a on t.f_central_lvl= a.F_ID
left join V_BASE_REGIONALISM  b on t.f_city= b.F_ID
left join t_base_grid  c on t.f_gridid= c.F_ID
where t.f_visable=1
/
