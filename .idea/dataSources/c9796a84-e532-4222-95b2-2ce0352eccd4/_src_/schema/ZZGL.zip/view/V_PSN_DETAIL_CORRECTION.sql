CREATE VIEW V_PSN_DETAIL_CORRECTION AS select t.f_sqjz fsqjzval,--社区矫正人员标志
       t.f_gridid, --所属网格ID
       q.f_grid_nm, --所属网格名称
       t.f_id, --主键
       t.f_id_card, --身份证号
       t.f_name, --姓名
       t.fsexname,--性别
       t.fnationname,--民族
       t.fxzname,--住址
       t.F_PHOTO, --照片
       ------------------------------------状态标识开始------------------------------------------------
       decode(t.f_attention_yn, 1, '重点关注人员', 0, '', '') f_attention_yn, --重点关注人员
       decode(t.f_floatflag, 1, '流动人口', 0, '户籍人口', '户籍人口') f_floatflag, --数据类别
       decode(t.f_lsry, 1, '留守人员', 0, '', '') f_lsry,
       decode(t.f_xmsf, 1, '刑满释放人员', 0, '', '') f_xmsf,
       decode(t.f_sqjz, 1, '社区矫正', 0, '', '') f_sqjz,
       decode(t.f_jsza, 1, '精神障碍', 0, '', '') f_jsza,
       decode(t.f_xdry, 1, '留守人员', 0, '', '') f_xdry,
       decode(t.f_aids, 1, '艾滋人员', 0, '', '') f_aids,
       decode(t.f_zdqsn, 1, '重点青少年', 0, '', '') f_zdqsn,
       ------------------------------------状态标识结束------------------------------------------------
       ------------------------------------社区矫正人员属性开始------------------------------------------------
       r3.F_COMM_RECT_MAN_NO, --     社区矫正人员编号
       r3.F_ORIG_PRISI_PLACE, --   原羁押场所

       r3.F_RECT_TYPE,-- 矫正类别 id
       ar3.F_NAME F_RECT_TYPEname, -- 矫正类别 v_base_correcttype

       r3.F_CASE_TYPE,--案件类别id
       br3.F_NAME F_CASE_TYPEname, --案件类别 v_base_case

       r3.F_CHAR_DETAIL, -- 具体罪名
       r3.F_ORIG_JUD_PRIS_TERM, --   原判刑期
       r3.F_ORIG_JUD_BEGI_DATE, --     原判刑开始时间yyyy-mm-dd
       r3.F_ORIGI_JUDG_END_DATE, --     原判刑结束时间yyyy-mm-dd
       r3.F_RECT_BEG_DATE, --      矫正开始时间yyyy-mm-dd
       r3.F_RECT_END_DATE, --      矫正结束时间yyyy-mm-dd

      r3.F_RECE_WAY,--      接收方式id
       cr3.F_NAME F_RECE_WAYname, --      接收方式 v_base_receiveway

       r3.F_SISHI_QI, --        四史情况id
       dr3.F_NAME F_SISHI_QIname, --        四史情况 v_base_sishi
       r3.F_IF_CIDIV, --     是否累惯犯 是：1 否：0


       r3.F_SAN_SHE_QING, --   三涉情况 id
       mr3.F_NAME F_SAN_SHE_QINGname,--三涉情况v_base_sanshe

       r3.F_IF_BUI_RECT_GROUP, --    是否建立矫正小组 是：1 否：0

       r3.F_RECT_GRO_M_STAT,-- 矫正小组人员组成情况id
       er3.F_NAME F_RECT_GRO_M_STATname, --   矫正小组人员组成情况 v_base_correctteamper

       r3.F_RELI_RECT_TYPE,--    解除矫正类型 id
       fr3.F_NAME F_RELI_RECT_TYPEname, --    解除矫正类型 v_base_correctlift
       r3.F_ESCAPE, --   是否有脱管 是：1 否：0
       r3.F_ESCAPEREASON, --   脱管原因
       r3.F_CHECKESCAPEDETAIL, --  检查监督脱管情况
       r3.F_ESCAPECORRECTDETAIL, --  脱管纠正情况
       r3.F_MISS, --     是否有漏管  是：1 否：0
       r3.F_MISSREASON, --   漏管原因
       r3.F_CHECKMISSDETAIL, --    检查监督漏管原因
       r3.F_MISSCORRECTDETAIL, --     漏管纠正情况
       r3.F_REWARDPUNISH, --     奖惩情况
       r3.F_PENALTYCHANGE, --    刑罚变更执行情况
       r3.F_RECRIME, --是否重新犯罪  是：1 否：0
       r3.F_RE_CHARGE_DETAIL --    重新犯罪名称
------------------------------------社区矫正人员属性结束------------------------------------------------ */

  from v_psn_resident t
  left join v_base_grid q on t.f_gridid = q.F_ID
  left join T_SPEC_COMM r3 on t.f_id_card = r3.f_id_num --社区矫正人员
  left join v_base_correcttype ar3 on r3.F_RECT_TYPE = ar3.F_ID
  left join v_base_case br3 on r3.F_CASE_TYPE = br3.F_ID
 left join v_base_receiveway cr3 on r3.F_RECE_WAY = cr3.F_ID
  left join v_base_sishi dr3 on r3.F_SISHI_QI = dr3.F_ID
  left join v_base_sanshe mr3 on r3.f_san_she_qing = mr3.F_ID
  left join v_base_correctteamper er3 on r3.F_RECT_GRO_M_STAT =  er3.F_ID
  left join v_base_correctlift fr3 on r3.F_RELI_RECT_TYPE = fr3.F_ID


 where t.f_visable = 1


/*社区矫正人员视图*/
/
