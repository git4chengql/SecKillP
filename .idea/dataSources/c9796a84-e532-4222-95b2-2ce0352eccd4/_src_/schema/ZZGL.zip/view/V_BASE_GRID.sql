CREATE VIEW V_BASE_GRID AS select t.*,
a.F_NAME fsexname, b.F_NAME fnationname,
c.F_NAME fstatusname,d.F_NAME feduname,
p.AREANAME f_AreaName,
s.F_NAME f_regionname
from T_BASE_GRID t
left join  V_BASE_SEX a  on t.f_sex=a.F_ID
left join V_BASE_NATION b on t.f_nation=b.F_ID
left join  V_BASE_STATUS c on t.F_POLITICS=c.F_ID
left join V_BASE_EDU d on t.f_education=d.F_ID
left join t_base_area p on p.FID = t.f_Areaid
left join v_base_regionalism s on t.f_areaid=s.F_ID
where t.f_visable=1
/
