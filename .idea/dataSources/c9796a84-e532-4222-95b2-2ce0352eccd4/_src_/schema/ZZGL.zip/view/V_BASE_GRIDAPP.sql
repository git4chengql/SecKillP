CREATE VIEW V_BASE_GRIDAPP AS select t.f_id,t.f_grid_nm f_name
from T_BASE_GRID t
/
