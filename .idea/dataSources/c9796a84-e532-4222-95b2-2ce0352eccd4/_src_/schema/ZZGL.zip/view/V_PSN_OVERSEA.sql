CREATE VIEW V_PSN_OVERSEA AS select  t.*,
 a.F_NAME fsexname,
 b.F_NAME fnationalityname,
c.F_NAME fzjdm,--证件代码
d.F_NAME flhmd,--来华目的
e.F_NAME fjobtypename,
f.F_NAME  fxzname,
g.f_grid_nm fgridname,--网格名称
h.F_NAME  ffaithname,--宗教信仰
l.f_x,l.f_y,l.f_gisid
from T_PSN_OVERSEA t
left join v_base_sex a  on t.f_sex=a.F_ID
left join v_base_nationality b on t.f_area= b.F_ID
left join v_base_identificationcode c on t.F_CARD_CODE=c.F_ID
left join v_base_goalinChina d on t.F_PORP=d.F_ID
left join v_base_jobtype e on t.F_DUTY_TYPE=e.F_ID
left join v_base_regionalism f on t.f_liveaddress=f.F_ID
left join t_base_grid g on t.f_gridid=g.f_id
left join v_base_religion h on t.f_religion=h.F_ID
left join t_psn_resident j on j.f_id_card=t.f_card_num
left join t_psn_house k on k.f_id=j.f_houseid
left join t_base_buildadm l on l.f_id=k.f_buildid
where t.f_visable=1
/
