CREATE VIEW V_SPEC_PSYHOSIS AS select t.*,
z.f_name zfname,--户籍人口表数据的开始
z.f_name_his zfnamehis,
z.f_sex zfsex,
z.f_id_card zfidcard,
z.f_birthday zfbirthday,
z.f_nation zfnation,
z.f_native zfnative,
z.f_marital zfmarital,
z.f_politics zpolitics,
z.f_education zfeduation,
z.f_faith   zffaith,
z.f_prf_type zfprftype,
z.f_profession zfprofession,
z.f_sev_place zfserplace,
z.f_phone zfphone,
z.F_REGISTER zfregister,
z.f_register_adrs zfregisteradrs,
z.F_ABODE zfabode,
z.F_ABODE_ADRS zfaboeadrs,
z.fsexname,
z.fnationname,
z.fnativename,
z.fmaritalname,
z.fstatusname,
z.feduname,
z.ffaithname,
z.fjobtypename,
z.f_native_name,
z.fhjname,
z.fxzname,
z.f_hjname,
z.f_xzname,--户籍人口表数据结束
k.F_NAME fjjzk,--经济状况
l.F_NAME fzdlx,--诊断类型
m.F_NAME  fwxdj,--危险登记
n.F_NAME fzlqk,--治疗情况
o.F_NAME fzlyy,--治疗原因
p.F_NAME fglry,--管理人员
q.F_NAME fbzqk,--帮助情况
a.f_grid_nm fgridname,--网格名称
z.f_x,z.f_y,z.f_gisid
from  T_SPEC_PSYCHOSIS t
left join v_psn_resident z on t.f_id_num=z.f_id_card
left join v_base_familyeconomiccon k on t.F_FAMI_ECON_STATUS=k.F_ID
left join v_base_currentdiagnosticty l on t.F_NOW_DIAGNO=l.F_ID
left join v_base_curriskassessmentlev m on t.f_Now_Dang_Rank=m.f_id
left join v_base_treatment n on t.F_CURE_STATUS=n.F_ID
left join v_base_hospitalreasons o  on t.F_IN_HOSP_CURE_REAS=o.F_ID
left join v_base_managementperson p on t.F_PART_MANA_MEN=p.F_ID
left join v_base_helpcase q on t.F_HELP_STAT=q.F_ID
left join  t_base_grid  a on t.f_gridid=a.f_id
/
