CREATE VIEW V_ORG_NONPUB AS select t.F_ID,t.F_NAME,t.F_TYPE,t.F_ADDR,t.F_CONTACT,t.F_EMP_NUM,t.F_BUSINESS_NUM,t.F_ORGCODE,t.F_LEGAL_ID,t.F_LEGAL_NUM,t.F_LEGAL_NAME,t.F_LEGAL_CONTACT,t.F_SECURITY_NAME,t.F_SECURITY_CONTACT,t.F_BUSS_DANGER,t.F_SAFE_DANGER,t.F_ATTENTION,t.F_HAVE_CONDITION,t.F_HAVE_ORG,t.F_PARTY_NUM,t.F_HAVE_UNION,t.F_UNION_NUM,t.F_HAVE_YOUTH,t.F_YOUTH_NUM,t.F_HAVE_WOMEN,t.F_WOMEN_NUM,t.F_CREATDATE,t.F_X,t.F_Y,t.F_GRIDID,t.F_VISABLE,t.f_imgname,
a.F_NAME f_type_name, b.F_NAME f_legal_id_name,t.f_gisid,
c.F_NAME f_safe_danger_name, d.F_NAME f_attention_name,
(case t.f_buss_danger
when 0 then '否'
when 1 then '是'
else '未知'
end) as f_buss_danger_name,
(case t.f_have_condition
when 0 then '否'
when 1 then '是'
else '未知'
end) as f_have_condition_name,
(case t.f_have_org
when 0 then '否'
when 1 then '是'
else '未知'
end) as f_have_org_name,
(case t.f_have_union
when 0 then '否'
when 1 then '是'
else '未知'
end) as f_have_union_name,
(case t.f_have_youth
when 0 then '否'
when 1 then '是'
else '未知'
end) as f_have_youth_name,
(case t.f_have_women
when 0 then '否'
when 1 then '是'
else '未知'
end) as f_have_women_name,
e.f_grid_nm f_gridid_name
from T_ORG_NONPUB t
left join v_base_companytype  a on t.f_type= a.F_ID
left join v_base_identificationcode  b on t.f_legal_id= b.F_ID
left join v_base_safehazardtype  c on t.f_safe_danger= c.F_ID
left join v_base_focuslevel  d on t.f_attention= d.F_ID
left join t_base_grid  e on t.f_gridid= e.F_ID
where t.f_visable=1
/
