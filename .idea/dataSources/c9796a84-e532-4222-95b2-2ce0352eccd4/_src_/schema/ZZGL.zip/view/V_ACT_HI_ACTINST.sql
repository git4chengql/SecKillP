CREATE VIEW V_ACT_HI_ACTINST AS select t.*,a.humandesc from act_hi_actinst t
left join tchuman a on a.humanid=t.assignee_
/
