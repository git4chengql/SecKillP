CREATE VIEW V_PSN_LSRY AS select  t.*,
z.f_name zfname,--户籍人口表数据的开始
z.f_name_his zfnamehis,
z.f_sex zfsex,
z.f_id_card zfidcard,
z.f_birthday zfbirthday,
z.f_nation zfnation,
z.f_native zfnative,
z.f_marital zfmarital,
z.f_politics zpolitics,
z.f_education zfeduation,
z.f_faith   zffaith,
z.f_prf_type zfprftype,
z.f_profession zfprofession,
z.f_sev_place zfserplace,
z.f_phone zfphone,
z.F_REGISTER zfregister,
z.f_register_adrs zfregisteradrs,
z.F_ABODE zfabode,
z.F_ABODE_ADRS zfaboeadrs,
z.fsexname,
z.fnationname,
z.fnativename,
z.fmaritalname,
z.fstatusname,
z.feduname,
z.ffaithname,
z.fjobtypename,
z.fhjname,
z.fxzname,
z.f_native_name,
z.f_hjname,
z.f_xzname,--户籍人口表数据结束
k.F_NAME fhealthname,--健康状况
l.F_NAME flstypename,--留守人员类型
m.F_NAME flsgxname,--与留守人员关系
a.f_grid_nm fgridname,--网格名称
d.f_x,d.f_y,d.f_gisid
from t_psn_lsry t
left join v_psn_resident z on t.f_persionid=z.f_id_card
left join v_base_health k on  t.f_health=k.F_ID
left join v_base_rearpersonnelty l  on  t.F_LEFTPERSONELTYPE=l.F_ID
left join v_base_guardianrelation m on t.F_LEFTPERSONELRELATIONSHIP=m.F_ID
left join  t_base_grid  a on t.f_gridid=a.f_id
left join t_psn_resident b on b.f_id_card=t.f_persionid
left join t_psn_house c on c.f_id=b.f_houseid
left join t_base_buildadm d on d.f_id=c.f_buildid
where t.f_visable=1
/
