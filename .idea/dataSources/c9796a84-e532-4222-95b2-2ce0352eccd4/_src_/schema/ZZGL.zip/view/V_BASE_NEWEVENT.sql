CREATE VIEW V_BASE_NEWEVENT AS select t.*,
to_char(t.f_creatdate,'yyyy-mm-dd hh24:mi:ss') f_create_date,
a.F_NAME flevelname,--案件分级
b.F_NAME ftypename,--案件类型
c.F_GRID_NM fgridname,--网格名称
d.F_NAME fidcardname,--主要当事人证件代码
e.F_NAME fmedname,--化解方式
f.F_NAME fsexname,--性别
g.F_NAME fnationname,--民族
h.F_NAME feduname,--学历
i.F_NAME fpersonname,-- 主要当事人人员类别
j.F_NAME fcasename,--案件性质
k.F_NAME fzfxryzjhm,--主犯(嫌疑人)证件代码
z.f_acceptedid,
q.humandesc f_reportername,--上报者姓名
--
n.name_ taskName,--阶段名称
n.id_ taskId,--阶段标识
n.proc_inst_id_ processInstanceId, -- 实例ID
r.proc_inst_id_ processhistoryid,
u.F_NAME scalename
--
from
t_base_event t
left join  v_base_eventlevel a on   t.f_evt_level=a.F_ID
left join  v_base_eventtype  b on t.f_evt_type=b.F_ID
left join  T_BASE_GRID       c on t.f_gridid=c.f_Id
left join  v_base_identificationcode d on t.F_MAINPSNID=d.F_ID
left join  v_base_resolveway e on t.F_MED=e.F_ID
left join  v_base_sex f on t.f_sex=f.F_ID
left join  v_base_nation g on t.f_nation=g.F_ID
left join  v_base_edu h on t.f_edu=h.F_ID
left join  v_base_mainpersoncategory   i on  t.F_PERSONTYPE=i.F_ID
left join  t_Rec_Act z on t.f_act_id = z.f_id
left join  v_base_eventcharacter  j on t.F_CASE_NAT=j.F_ID
left join  v_base_identificationcode k on t.F_PRI_CODE=k.F_ID
left join  Act_Ru_Execution m on t.f_Evt_No = m.business_key_
left join  Act_Ru_Task n on m.id_ = n.execution_id_
left join  tchuman q on q.humanid = t.f_reporter
left join  Act_Hi_Procinst r on t.f_Evt_No = r.business_key_

left join v_base_eventscale u on t.F_CASE_SCALE = u.F_ID
order by t.f_pro_status,t.f_creatdate desc
/
