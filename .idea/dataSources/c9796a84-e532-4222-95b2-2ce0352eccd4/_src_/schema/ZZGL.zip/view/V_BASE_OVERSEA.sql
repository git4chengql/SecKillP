CREATE VIEW V_BASE_OVERSEA AS select  t.*, a.F_NAME fsexname,b.F_NAME fnationalityname
from T_PSN_OVERSEA t
left join v_base_sex a  on t.f_sex=a.F_ID
left join v_base_nationality b on t.f_area= b.F_ID
/
