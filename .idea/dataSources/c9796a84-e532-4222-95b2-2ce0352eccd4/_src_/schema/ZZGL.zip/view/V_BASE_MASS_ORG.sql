CREATE VIEW V_BASE_MASS_ORG AS select t.f_id,t.F_ORG_NM,t.F_ORG_TYPE,t.F_ORG_LVL,t.F_GUID_DEPT,t.F_STAFF_NUM,t.F_MAJ_DUTY,t.F_CREATDATE,t.F_GRIDID,t.F_VISABLE,
a.F_NAME f_masstype, b.F_NAME f_level,
c.f_grid_nm f_gridid_name,
t.f_region,
t.f_region_name
 from T_BASE_MASS_ORG t
left join v_base_masstype  a on t.f_org_type= a.F_ID
left join v_base_level  b on t.f_org_lvl= b.F_ID
left join t_base_grid  c on t.f_gridid= c.F_ID
where  t.f_visable=1
/
