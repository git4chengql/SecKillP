CREATE VIEW V_WORK_PATROL AS select t.*,
q.humandesc,q.unitname,q.telmobile,q.humanname,q.f_imgname,q.gridname
from t_work_patrol t
left join  vchuman  q on t.f_humanid=q.humanid
/
