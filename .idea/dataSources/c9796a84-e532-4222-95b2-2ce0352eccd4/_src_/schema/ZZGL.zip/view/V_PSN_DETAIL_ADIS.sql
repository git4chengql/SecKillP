CREATE VIEW V_PSN_DETAIL_ADIS AS select t.f_sqjz fsqjzval,--社区矫正人员标志
       t.f_gridid, --所属网格ID
       q.f_grid_nm, --所属网格名称
       t.f_id, --主键
       t.f_id_card, --身份证号
       t.f_name, --姓名
       t.fsexname,--性别
       t.fnationname,--民族
       t.fxzname,--住址
       t.F_PHOTO, --照片
       ------------------------------------状态标识开始------------------------------------------------
       decode(t.f_attention_yn, 1, '重点关注人员', 0, '', '') f_attention_yn, --重点关注人员
       decode(t.f_floatflag, 1, '流动人口', 0, '户籍人口', '户籍人口') f_floatflag, --数据类别
       decode(t.f_lsry, 1, '留守人员', 0, '', '') f_lsry,
       decode(t.f_xmsf, 1, '刑满释放人员', 0, '', '') f_xmsf,
       decode(t.f_sqjz, 1, '社区矫正', 0, '', '') f_sqjz,
       decode(t.f_jsza, 1, '精神障碍', 0, '', '') f_jsza,
       decode(t.f_xdry, 1, '吸毒人员', 0, '', '') f_xdry,
       decode(t.f_aids, 1, '艾滋人员', 0, '', '') f_aids,
       decode(t.f_zdqsn, 1, '重点青少年', 0, '', '') f_zdqsn,
       ------------------------------------状态标识结束------------------------------------------------
       ------------------------------------艾滋病人员属性开始------------------------------------------------

       r3.F_INFECT_WAY,--感染途径id
       ar3.F_NAME fgrtj, --感染途径 v_base_infection
       r3.F_IF_CRIMED, --是否有犯罪史
       r3.F_CRIME_DETAIL,--违法情况
       br3.F_NAME fajlbname,--案件类别 v_base_case

       r3.F_ATTEN_YPE,---关注类型id
       cr3.F_NAME fgzlxname,---关注类型 v_base_focusty
       r3.F_HELP_STATUS,--帮扶情况
       r3.F_HELP_MAN_NAME,--帮扶人姓名
       r3.F_HELP_MAN_CONT_WAY,--帮扶人联系方式
       dr3.F_NAME fszqk,--收治情况
       r3.F_CURE_AGEN_NAME--收治机构名称



------------------------------------艾滋病人员属性结束------------------------------------------------ */

  from v_psn_resident t
  left join v_base_grid q on t.f_gridid = q.F_ID
  left join t_spec_adis r3 on t.f_id_card = r3.f_id_num --艾滋病患者
  left join  v_base_infection ar3 on r3.F_INFECT_WAY = ar3.F_ID
  left join v_base_case br3 on r3.F_CASE_TYPE = br3.F_ID
  left join  v_base_focusty cr3 on r3.F_ATTEN_YPE = cr3.F_ID
  left join v_base_receiveandcure dr3 on r3.F_CURE_STATUS=dr3.F_ID

 where t.f_visable = 1


/*艾滋病人员视图*/
/
