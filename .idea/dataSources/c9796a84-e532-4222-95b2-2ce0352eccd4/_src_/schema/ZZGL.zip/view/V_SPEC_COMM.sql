CREATE VIEW V_SPEC_COMM AS select t.*,
z.f_name zfname,--户籍人口表数据的开始
z.f_name_his zfnamehis,
z.f_sex zfsex,
z.f_id_card zfidcard,
z.f_birthday zfbirthday,
z.f_nation zfnation,
z.f_native zfnative,
z.f_marital zfmarital,
z.f_politics zpolitics,
z.f_education zfeduation,
z.f_faith   zffaith,
z.f_prf_type zfprftype,
z.f_profession zfprofession,
z.f_sev_place zfserplace,
z.f_phone zfphone,
z.F_REGISTER zfregister,
z.f_register_adrs zfregisteradrs,
z.F_ABODE zfabode,
z.F_ABODE_ADRS zfaboeadrs,
z.fsexname,
z.fnationname,
z.fnativename,
z.fmaritalname,
z.fstatusname,
z.feduname,
z.ffaithname,
z.fjobtypename,
z.fhjname,
z.fxzname,
z.f_hjname,
z.f_xzname,--户籍人口表数据结束
k.F_NAME  fjzlb,--矫正类别
l.F_NAME  fajlb,--案件类别
m.F_NAME  fjsfs,--接受方式
n.F_NAME fssqk,--三涉情况
p.F_NAME  fjcjz,--接触矫正
q.F_NAME fsisqk,--四是情况
a.f_grid_nm fgridname,--网格名称
z.f_x,z.f_y,z.f_gisid,
b.f_name fjzxzcy--矫正小组成员
from  t_spec_comm t
left join v_psn_resident z on t.f_id_num=z.f_id_card
left  join v_base_correcttype k on t.F_RECT_TYPE=k.F_ID
left join  v_base_case l on t.F_CASE_TYPE=l.F_ID
left join v_base_receiveway  m on t.F_RECE_WAY=m.F_ID
left join v_base_sanshe n on t.F_SAN_SHE_QING=n.F_ID
left join  v_base_correctlift p on t.F_RELI_RECT_TYPE=p.F_ID
left join v_base_sishi q on t.f_sishi_qi=q.F_ID
left join  t_base_grid  a on t.f_gridid=a.f_id
left join v_base_correctteamper  b on t.f_rect_gro_m_stat= cast( b.F_ID as varchar2(50) )
where t.f_visable=1
/
