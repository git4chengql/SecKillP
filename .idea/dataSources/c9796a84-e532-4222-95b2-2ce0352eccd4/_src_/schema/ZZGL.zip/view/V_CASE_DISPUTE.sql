CREATE VIEW V_CASE_DISPUTE AS select t.*,a.f_name fscalename,b.f_name ftypename,c.f_name fidcodename,d.F_NAME fsexname,
  e.F_NAME fnativename,f.F_NAME feduname,g.f_name fsolvetypename,h.f_grid_nm fgridname
    from t_case_dispute t
    left join t_base_grid h on t.f_gridid=h.f_id
   left join v_base_code a on t.f_case_scale=a.f_id
   left join v_base_code b on t.f_case_type=b.f_id
   left join v_base_code c on t.f_idcode=c.f_id
   left join v_base_sex d on t.f_sex=d.F_ID
   left join v_base_nation e on t.f_native=e.F_ID
   left join v_base_edu f on t.f_edu=f.F_ID
   left join v_base_code g on t.f_solvetype=g.f_id
/
