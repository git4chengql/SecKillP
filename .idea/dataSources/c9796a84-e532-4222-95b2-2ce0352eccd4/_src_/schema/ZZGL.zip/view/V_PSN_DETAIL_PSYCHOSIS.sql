CREATE VIEW V_PSN_DETAIL_PSYCHOSIS AS select t.f_sqjz fsqjzval,--社区矫正人员标志
       t.f_gridid, --所属网格ID
       q.f_grid_nm, --所属网格名称
       t.f_id, --主键
       t.f_id_card, --身份证号
       t.f_name, --姓名
       t.fsexname,--性别
       t.fnationname,--民族
       t.fxzname,--住址
       t.F_PHOTO, --照片
       ------------------------------------状态标识开始------------------------------------------------
       decode(t.f_attention_yn, 1, '重点关注人员', 0, '', '') f_attention_yn, --重点关注人员
       decode(t.f_floatflag, 1, '流动人口', 0, '户籍人口', '户籍人口') f_floatflag, --数据类别
       decode(t.f_lsry, 1, '留守人员', 0, '', '') f_lsry,
       decode(t.f_xmsf, 1, '刑满释放人员', 0, '', '') f_xmsf,
       decode(t.f_sqjz, 1, '社区矫正', 0, '', '') f_sqjz,
       decode(t.f_jsza, 1, '精神障碍', 0, '', '') f_jsza,
       decode(t.f_xdry, 1, '留守人员', 0, '', '') f_xdry,
       decode(t.f_aids, 1, '艾滋人员', 0, '', '') f_aids,
       decode(t.f_zdqsn, 1, '重点青少年', 0, '', '') f_zdqsn,
       ------------------------------------状态标识结束------------------------------------------------
       ------------------------------------严重精神病患者属性开始------------------------------------------------

       r3.F_FAMI_ECON_STATUS,-- 家庭经济状况id
       ar3.F_NAME fjtjjzk, -- 家庭经济状况 v_base_familyeconomiccon
       r3.F_IF_LOW_SECU, --是否纳入低保
       r3. F_GUAR_ID fjhrsfzh,--监护人身份账号   v_base_citizenidenum
       r3.F_GUAR_NAME,---监护人姓名
       r3.F_FIRST_ATTA_DATE,--初次发病日期

       r3.F_NOW_DIAGNO,--目前诊断类型id
       cr3.F_NAME fmqzdlx,--目前诊断类型
       r3.F_CRIME,--是否有肇祸史
       r3.F_CRIME_TIME,--肇祸次数
       r3.F_ORIG_CRIM_DATE,--上次肇祸时间

       r3.F_NOW_DANG_RANK,--危险性等级id
       dr3.F_NAME fwxxdj,--危险性等级

       r3.F_CURE_STATUS,--治疗情况id
       er3.F_NAME fzlqk,--治疗情况

      r3.F_CURE_HOS_NAME,--治疗医院名称

      r3.F_IN_HOSP_CURE_REAS,--住院治疗原因id
       fr3.F_NAME fzyzlyy,--住院治疗原因
       r3.F_RE_TR_ORG_NAME,--接收康复训练的结构名称

       r3.F_PART_MANA_MEN,--参与管理的人员id
       gr3.F_NAME F_PART_MANA_MENname,--参与管理的人员

       r3.F_HELP_STAT,--帮扶情况id
       hr3.F_NAME fbfqk,--帮扶情况
       r3.F_GUAR_CONT_WAY--监护人联系方式


------------------------------------严重精神病患者属性结束------------------------------------------------ */

  from v_psn_resident t
  left join v_base_grid q on t.f_gridid = q.F_ID
  left join t_spec_psychosis r3 on t.f_id_card = r3.f_id_num --严重精神病患者
  left join  v_base_familyeconomiccon ar3 on r3.F_FAMI_ECON_STATUS = ar3.F_ID
  left join v_base_citizenidenum br3 on r3.F_GUAR_ID = br3.F_ID
  left join  v_base_currentdiagnosticty cr3 on r3.F_NOW_DIAGNO = cr3.F_ID
  left join v_base_curriskassessmentlev dr3 on r3.F_NOW_DANG_RANK=dr3.F_ID
  left join  v_base_treatment er3 on r3.F_CURE_STATUS=er3.F_ID
  left join v_base_hospitalreasons fr3 on r3.F_IN_HOSP_CURE_REAS=fr3.F_ID
  left join  v_base_managementperson gr3 on r3.F_PART_MANA_MEN=gr3.F_ID
  left join   v_base_helpcase hr3 on r3.F_HELP_STAT=hr3.F_ID
 where t.f_visable = 1


/*严重精神病患者视图*/
/
