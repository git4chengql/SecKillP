CREATE VIEW V_BASE_EVENT AS select t.*,
to_char(t.f_creatdate,'yyyy-mm-dd hh24:mi:ss') f_create_date,
a.F_NAME flevelname,--案件分级
b.F_NAME ftypename,--案件类型
c.F_GRID_NM fgridname,--网格名称
d.F_NAME fidcardname,--主要当事人证件代码
e.F_NAME fmedname,--化解方式
f.F_NAME fsexname,--性别
g.F_NAME fnationname,--民族
h.F_NAME feduname,--学历
i.F_NAME fpersonname,-- 主要当事人人员类别
j.F_NAME fcasename,--案件性质
k.F_NAME fzfxryzjhm,--主犯(嫌疑人)证件代码
n.f_acceptedid,
r.f_nodetype,
m.f_actname,
w.f_feedbck,
man.humandesc ,
se.F_NAME f_eventsename

from
t_base_event t
left join  v_base_eventlevel a on   t.f_evt_level=a.F_ID
left join  v_base_eventtype  b on t.f_evt_type=b.F_ID
left join  T_BASE_GRID       c on t.f_gridid=c.f_Id
left join  v_base_identificationcode d on t.F_MAINPSNID=d.F_ID
left join  v_base_resolveway e on t.F_MED=e.F_ID
left join  v_base_sex f on t.f_sex=f.F_ID
left join  v_base_nation g on t.f_nation=g.F_ID
left join  v_base_edu h on t.f_edu=h.F_ID
left join  v_base_mainpersoncategory   i on  t.F_PERSONTYPE=i.F_ID
left join  v_base_eventcharacter  j on t.F_CASE_NAT=j.F_ID
left join  v_base_identificationcode k on t.F_PRI_CODE=k.F_ID
left join  t_wf_act_dic m on m.f_id=t.F_ACTIVE_STATUS
left join  t_Rec_Act n on t.f_act_id = n.f_id
left join  t_wf_node_dic r on r.f_nodeid=t.f_node_id
left join  t_ver_task w on w.f_evt_no=t.f_evt_no
left join   tchuman  man  on t.F_REPORTER=man.humanid
left join   v_base_eventscale se on t.F_CASE_SCALE=se.F_ID
order by t.f_pro_status,t.f_creatdate desc
/
