CREATE VIEW V_PSN_RESIDENT AS select t.*,a.F_NAME fsexname,b.F_NAME fnationname,
c.F_NAME fnativename,
d.F_NAME fmaritalname,e.F_NAME fstatusname,
f.F_NAME feduname,g.F_NAME ffaithname,h.F_NAME fjobtypename,
i.F_NAME fhjname,j.F_NAME fxzname,
k.F_NAME fyzbzname,--人户一致标志
l.F_NAME fyhzgxname,--与户主关系
m.F_NAME fwcqx,--外出去向地
n.F_NAME flryy,--流入原因
o.F_NAME fbzlx,--办证类型
p.F_NAME fzslx,--住所类型
q.f_grid_nm fgridname,--网格名称
s.f_x,s.f_y,s.f_gisid,
r.f_hou_addr,
decode(t.f_lsry,1,'是','否') f_lsryname,
decode(t.f_xmsf,1,'是','否') f_xmsfname,
decode(t.f_sqjz,1,'是','否') f_sqjzname,
decode(t.f_jsza,1,'是','否') f_jszaname,
decode(t.f_xdry,1,'是','否') f_xdryname,
decode(t.f_aids,1,'是','否') f_aidsname,
decode(t.f_zdqsn,1,'是','否') f_zdqsnname,
z.f_name fhousename,
se.f_hou_addr ffwdz--房屋地址*\*/
from t_psn_resident t
left join v_base_sex a on t.f_sex=a.F_ID
left join v_base_nation b on t.f_nation=b.F_ID
left join v_base_regionalism c on t.f_native=c.F_ID
left join v_Base_maritalstatu d on t.f_marital=d.F_ID
left join v_base_status e on t.f_politics=e.F_ID
left join v_base_edu f on t.f_education=f.F_ID
left join v_base_religion g on t.f_faith=g.F_ID
left join v_base_jobtype h on t.f_prf_type=h.F_ID
left join v_base_regionalism i on t.F_REGISTER=i.F_ID
left join v_base_regionalism j on t.F_ABODE=j.F_ID
left join  v_base_consistent  k on t.F_FAM_STATUS=k.F_ID
left join v_base_guardianrelation l on t.F_FAM_M_REL=l.F_ID
left join  v_base_regionalism m on  t.F_GOOUTTO=m.F_ID
left join  v_base_intoreason  n on t.F_FLOA_REASON=n.F_ID
left join  v_base_certificatety o on  t.F_PAPERS_TYPE=o.F_ID
left join  v_base_housetype p on t.F_ABODE_TYPE=p.F_ID
left join  t_base_grid  q on t.f_gridid=q.f_id
left join t_psn_house r on r.f_id=t.f_houseid
left join t_base_buildadm s on s.f_id=r.f_buildid
left join t_psn_house se on t.f_houseid=se.f_id
left join v_psn_resident_next z on t.f_fam_m_nm=z.F_ID
/
