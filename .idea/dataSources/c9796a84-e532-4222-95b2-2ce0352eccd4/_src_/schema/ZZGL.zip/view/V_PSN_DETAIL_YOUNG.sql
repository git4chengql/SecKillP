CREATE VIEW V_PSN_DETAIL_YOUNG AS select t.f_gridid, --所属网格ID
     q.f_grid_nm,--所属网格名称
       t.f_id, --主键
       t.f_id_card, --身份证号
       t.f_name, --姓名
       t.fsexname,--性别
       t.fnationname,--民族
       t.fxzname,--住址
       t.F_PHOTO, --照片
       ------------------------------------状态标识开始------------------------------------------------
       decode(t.f_attention_yn, 1, '重点关注人员', 0, '', '') f_attention_yn, --重点关注人员
       decode(t.f_floatflag, 1, '流动人口', 0, '户籍人口', '户籍人口') f_floatflag, --数据类别
       decode(t.f_lsry, 1, '留守人员', 0, '', '') f_lsry,
       decode(t.f_xmsf, 1, '刑满释放人员', 0, '', '') f_xmsf,
       decode(t.f_sqjz, 1, '社区矫正', 0, '', '') f_sqjz,
       decode(t.f_jsza, 1, '精神障碍', 0, '', '') f_jsza,
       decode(t.f_xdry, 1, '吸毒人员', 0, '', '') f_xdry,
       decode(t.f_aids, 1, '艾滋人员', 0, '', '') f_aids,
       decode(t.f_zdqsn, 1, '重点青少年', 0, '', '') f_zdqsn,
       ------------------------------------状态标识结束------------------------------------------------

      ------------------------------------重点青少年属性开始------------------------------------------------
   /* u.F_NAME F_MAN_TYPEname,*/--青少年人员类型 v_base_persontype
      r.f_man_type,--青少年人员类型id
       r.F_FAMI_STAT,--家庭情况id
     v.F_NAME F_FAMI_STATname,--家庭情况 v_base_familytype
       r.F_SCHOOLNAME, --   学校名称
       r.F_WORKUNIT,--工作单位

       r.F_GUAR, --监护人身份证号
       r.F_GUAR_NAME, --监护人姓名
       r.F_GUAR_CONT_WAY, --   监护人联系方式
       r.F_GUAR_LIVE_PLACE, --监护人居住详址
       r.f_foucslevel,-- 关注程度id
      z.F_NAME f_foucslevelname,--关注程度v_base_focuslevel
       r.f_schoolev,--学校所属层级id
      m.F_NAME f_schoolevname,--学校所属层级v_base_level
       r.f_magtype,--管理手段id
       n.F_NAME f_magtypename,--管理手段v_base_managetool
       r.f_crimetype,--犯罪类型id
       a.F_NAME f_crimetypename,--犯罪类型v_base_criminaltype
       r.f_guar_real,--与监护人关系id
       b.F_NAME f_guar_realname,--与监护人关系v_base_guardianrelation


       decode(r.F_IF_CRIME, '1', '是', '0', '否', '否') F_IF_CRIME, --是否违法犯罪  1:是，0：否
       r.F_CRIMESITUATION,--违法情况id
      s.F_NAME F_CRIMESITUATIONname, --违法情况 v_base_criminalsituation
       r.F_HELP_MAN_NAME, --帮扶人姓名
       r.F_HELP_MAN_CONT_WAY, --帮扶人联系方式

       r.F_HELP_WAY,----帮扶手段id
       x.F_NAME F_HELP_WAYname, --帮扶手段v_base_helptype
       r.f_help_stat,--帮扶情况
       r.f_Psntype,--实口类型
       r.F_FIXED--有无固定住所
       ------------------------------------重点青少年属性结束------------------------------------------------


  from v_psn_resident t
  left join T_YOUN_EMP_TEEN r on t.f_id_card = r.f_id_num     --重点青少年
 left join v_base_grid q on t.f_gridid = q.F_ID
   left join v_base_criminalsituation s on r.F_CRIMESITUATION = s.F_ID
/*left join v_base_persontype u on r.F_MAN_TYPE=u.F_ID*/
 left join v_base_familytype v on r.F_FAMI_STAT=v.F_ID
  left join v_base_guardianrelation w on r.F_GUAR_REAL=w.F_ID
  left join v_base_helptype x on r.f_help_way = x.f_id
 left join  v_base_focuslevel z on r.f_foucslevel = z.f_id
  left join  v_base_level m on r.f_schoolev = m.F_ID
  left join v_base_managetool n on r.f_magtype = n.f_id
  left join v_base_criminaltype a on r.f_crimetype = a.f_id
  left join v_base_guardianrelation b on r.f_guar_real = b.f_id

 where t.f_visable = 1
/
