CREATE VIEW V_SCHOOL_MAIN AS select t.F_ID,t.F_SCH_NM,t.F_SCH_ADD,t.F_SCH_TYPE,t.F_STU_NUM,t.F_PRI_NM,t.F_PRI_TEL,t.F_SAFE_NM,t.F_SAFE_TEL,t.F_POL_NM,t.F_POL_TEL,t.F_SAFE_NUM,t.F_DEP_TYPE,t.F_X,t.F_Y,t.F_CREATDATE,t.F_GRIDID,t.F_VISABLE,t.f_pub_secu,t.f_pub_secu_tel,t.f_imgname,t.dep_name,
t.F_GISID,
a.F_NAME f_sch_type_name, b.F_NAME f_dep_type_name,
c.f_grid_nm f_gridid_name
from T_SCHOOL_MAIN t
left join v_base_schooledutype  a on t.f_sch_type= a.F_ID
left join v_base_regionalism  b on t.f_dep_type= b.F_ID
left join t_base_grid  c on t.f_gridid= c.F_ID
where t.f_visable=1
/
