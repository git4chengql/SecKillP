CREATE VIEW V_GRIDTREE AS select
   m.FID  id,
   g.f_grid_nm text,
   g.f_Areaid pid,
   (case
         when (select COUNT(1)
                 from t_Human_Grid d1
                where d1.gridid = m.Fid
                 ) > 0 then
          1
         else
          0
       end) as checked
 from
  v_Base_Grid g
  left join v_BaseArea4Px m on m.FID = g.f_Areaid

union
  select
    n.FID id,
    n.AREANAME text,
    n.PARENTID pid,
    0 checked
  from v_BaseArea4Px n
/
