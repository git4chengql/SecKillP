CREATE VIEW V_BASE_EVENTHISHUMAN AS select t.f_evt_no ,
b.assignee_
from t_base_event t
left join act_ru_execution  a  on t.f_evt_no=a.business_key_
left join act_hi_actinst  b  on a.proc_inst_id_=b.proc_inst_id_
where assignee_  is not null
/
