CREATE VIEW VCREGION AS select d.RegionName as DistrictName,
       c.RegionName as StreetName,
       b.RegionName as CommunityName,
       a.RegionName as CellName,
       d.RegionID   as DistrictID,
       c.RegionID   as StreetID,
       b.RegionID   as CommunityID,
       a.RegionID   as CellID,
       SubStr(c.JDDM,1,6) as CQDM,
       c.JDDM,b.SQDM,a.WGDM
  from zzgl.tcRegion a,
       zzgl.tcRegion b,
       zzgl.tcRegion c,
       zzgl.tcRegion d
  where a.RegionType = 5
    and a.SeniorID = b.RegionID
    and b.SeniorID = c.RegionID
    and c.SeniorID = d.RegionID
/
