CREATE VIEW V_PSN_HOUSE AS select  t.*,a.F_NAME constructname, b.F_NAME rentpurpname,c.F_NAME hazardtypename,
d.F_NAME citizenidenum,e.F_BUILD_NM buildname,f.F_NAME houownidtype,
g.f_grid_nm fgridname,
e.f_x,e.f_y,--坐标 e.f_gisid,
e.F_BUILD_NUMBER,--楼栋人数
e.F_BUILD_FLOOR--层数
from T_PSN_HOUSE t
left join v_base_constructionpurp a on t.F_BUILD_USE=a.F_ID
left join v_base_rentpurp b on t.F_RENT_USE=b.F_ID
left join v_base_hazardtype c on t.F_DANG_TYPE=c.F_ID
left join v_base_citizenidenum d on t.F_RENT_ID=d.F_ID
left join T_BASE_BUILDADM e on t.F_BUILDID=e.F_ID
left join v_base_identificationcode f on t.F_HOU_OWN_IDTYPE=f.F_ID
left join  T_BASE_GRID g on t.f_gridid=g.f_id
/
