CREATE VIEW V_BASE_CMTPSV AS select t.*,a.f_grid_nm f_gridid_name
from T_BASE_CMTPSV t
left join t_base_grid a on t.f_gridid=a.f_id
 where t.f_visable=1
/
