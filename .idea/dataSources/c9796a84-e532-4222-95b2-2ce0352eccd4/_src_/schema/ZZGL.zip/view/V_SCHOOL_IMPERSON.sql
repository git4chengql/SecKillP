CREATE VIEW V_SCHOOL_IMPERSON AS select t.*,
a.F_NAME f_gender_name, b.F_NAME f_nation_name,
c.F_NAME f_address_name, d.F_NAME f_mar_sta_name,
e.F_NAME f_pol_sta_name, f.F_NAME f_edu_name,
g.F_NAME f_rel_bel_name, h.F_NAME f_occ_class_name,
i.F_NAME f_pla_reg_name, j.F_NAME f_curr_res_name,
k.F_NAME f_ext_inj_name, l.F_SCH_NM f_schoolid_name,
(case t.f_whe_att
when 0 then '否'
when 1 then '是'
else '未知'
end) as f_whe_att_name,
m.f_grid_nm f_gridid_name
from T_SCHOOL_IMPERSON t
left join v_base_sex  a on t.f_gender= a.F_ID
left join v_base_nation  b on t.f_nation= b.F_ID
left join v_base_regionalism  c on t.f_address= c.F_ID
left join v_base_maritalstatu  d on t.f_mar_sta= d.F_ID
left join v_base_status  e on t.f_pol_sta= e.F_ID
left join v_base_edu  f on t.f_edu= f.F_ID
left join v_base_religion  g on t.f_rel_bel= g.F_ID
left join v_base_jobtype  h on t.f_occ_class= h.F_ID
left join v_base_regionalism  i on t.f_pla_reg= i.F_ID
left join v_base_regionalism  j on t.f_curr_res= j.F_ID
left join v_base_hazarddegree  k on t.f_ext_inj= k.F_ID
left join t_school_main  l on t.f_schoolid= l.F_ID
left join t_base_grid  m on t.f_gridid= m.F_ID
where t.f_visable=1
/
