CREATE VIEW V_ROAD_ACCIDENT AS select  t.*,a.F_ADDNAME addname
from t_road_accident t
left join  T_ROAD_PROLINE a on t.F_ADD_ID=a.f_id
/
