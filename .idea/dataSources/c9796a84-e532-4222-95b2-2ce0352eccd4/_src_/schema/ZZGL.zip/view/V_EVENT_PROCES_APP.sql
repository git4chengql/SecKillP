CREATE VIEW V_EVENT_PROCES_APP AS select to_char(t.act_Name_) nodeName,
               to_char(t.start_time_, 'YYYY-MM-DD HH24:MI') startTime1,
              to_char(a.createtime, 'YYYY-MM-DD HH24:MI') startTime,
              a.taskid,
              t.task_id_,
               h.humandesc assigner,
               a.note,
               a.noteimg noteImg,
               t.proc_Inst_Id_
          from ACT_HI_ACTINST t
          left join t_Act_Note a
            on t.Task_Id_ = a.taskid
          left join tcHuman h
            on t.assignee_ = h.humanid
         where t.act_type_ != 'startEvent'
           and t.end_time_ is not null
/
