CREATE VIEW V_PSN_HOUSERENTDETAIL AS select  t.*,a.F_HOU_ID houseid,b.F_NAME rentuse
from T_PSN_HOUSERENTDETAIL t
left join T_PSN_HOUSE a on t.F_HOUSEID=a.F_ID
left join v_base_usetypes b on t.F_USETYPE=b.F_ID
/
