CREATE VIEW V_PSN_DETAIL_DRUG AS select t.f_sqjz fsqjzval,--社区矫正人员标志
       t.f_gridid, --所属网格ID
       q.f_grid_nm, --所属网格名称
       t.f_id, --主键
       t.f_id_card, --身份证号
       t.f_name, --姓名
       t.fsexname,--性别
       t.fnationname,--民族
       t.fxzname,--住址
       t.F_PHOTO, --照片
       ------------------------------------状态标识开始------------------------------------------------
       decode(t.f_attention_yn, 1, '重点关注人员', 0, '', '') f_attention_yn, --重点关注人员
       decode(t.f_floatflag, 1, '流动人口', 0, '户籍人口', '户籍人口') f_floatflag, --数据类别
       decode(t.f_lsry, 1, '留守人员', 0, '', '') f_lsry,
       decode(t.f_xmsf, 1, '刑满释放人员', 0, '', '') f_xmsf,
       decode(t.f_sqjz, 1, '社区矫正', 0, '', '') f_sqjz,
       decode(t.f_jsza, 1, '精神障碍', 0, '', '') f_jsza,
       decode(t.f_xdry, 1, '吸毒人员', 0, '', '') f_xdry,
       decode(t.f_aids, 1, '艾滋人员', 0, '', '') f_aids,
       decode(t.f_zdqsn, 1, '重点青少年', 0, '', '') f_zdqsn,
       ------------------------------------状态标识结束------------------------------------------------
       ------------------------------------吸毒人员属性开始------------------------------------------------
       r3.F_FIRST_DESC_DATE,--初次发现时间

       r3.F_CONT_STATUS, -- 管控情况id
       ar3.F_NAME fgkqk, -- 管控情况v_base_control
       r3.F_CONT_MAN_NAME, --管控人姓名
       r3.F_CONT_MAN_CON_WAY,--管控人联系方式
       r3.F_HELP_STATUS,---帮扶情况
       r3.F_HELP_MAN_NAME,--帮扶人姓名
       r3.F_HELP_MAN_CONT_WAY,--帮扶人联系方式
       r3.F_IF_CRIMED,--有无犯罪史
       r3.F_CRIME_STATUS,--犯罪情况
       br3.F_NAME fxdyy,--吸毒原因
       cr3.F_NAME fxdhg--吸毒后果


------------------------------------吸毒人员属性结束------------------------------------------------ */

  from v_psn_resident t
  left join v_base_grid q on t.f_gridid = q.F_ID
  left join t_spec_drug r3 on t.f_id_card = r3.f_id_num --吸毒人员
  left join  v_base_control  ar3 on r3.F_CONT_STATUS = ar3.F_ID
  left join v_base_drugreason br3 on r3.F_DRUG_REASON = br3.F_ID
  left join  v_base_drugconsequence cr3 on r3.F_DRUG_EFFECT = cr3.F_ID
 where t.f_visable = 1


/*吸毒人员视图*/
/
