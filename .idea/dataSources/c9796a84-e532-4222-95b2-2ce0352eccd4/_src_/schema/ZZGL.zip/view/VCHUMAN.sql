CREATE VIEW VCHUMAN AS select t.*,
unit.unitname f_unitname,
q.f_grid_nm gridname--网格名称
from tchuman t
left join  t_base_grid  q on t.gridid=q.f_id
left join   tcunit  unit  on t.unitid=unit.unitid
/
