CREATE VIEW V_SCHOOL_SAFE AS select t.*,a.F_NAME fcaseprop, b.F_NAME fcardcode,c.f_grid_nm fgridname
from T_SCHOOL_SAFE t
left join v_base_eventcharacter a on t.f_case_prop=a.F_ID
left join v_base_identificationcode b on t.f_card_code=b.F_ID
left join  T_BASE_GRID c on t.f_gridid=c.f_id
/
