CREATE VIEW V_PSN_RESIDENT_ALL AS select t.f_gridid, --所属网格ID
       q.f_grid_nm, --所属网格名称
       t.f_id, --主键
       t.f_id_card, --身份证号
       t.f_name, --姓名
       t.F_PHOTO, --照片
       a.F_NAME fsexname, --性别 v_base_sex
       b.F_NAME fnationname, --民族 v_base_nation
       c.F_NAME fnativename, --籍贯 v_base_regionalism

       ------------------------------------状态标识开始------------------------------------------------
       decode(t.f_attention_yn, 1, '重点关注人员', 0, '', '') f_attention_yn, --重点关注人员
       decode(t.f_floatflag, 1, '流动人口', 0, '户籍人口', '户籍人口') f_floatflag, --数据类别
       decode(t.f_lsry, 1, '留守人员', 0, '', '') f_lsry,
       decode(t.f_xmsf, 1, '刑满释放人员', 0, '', '') f_xmsf,
       decode(t.f_sqjz, 1, '社区矫正', 0, '', '') f_sqjz,
       decode(t.f_jsza, 1, '精神障碍', 0, '', '') f_jsza,
       decode(t.f_xdry, 1, '留守人员', 0, '', '') f_xdry,
       decode(t.f_aids, 1, '艾滋人员', 0, '', '') f_aids,
       decode(t.f_zdqsn, 1, '重点青少年', 0, '', '') f_zdqsn,
       ------------------------------------状态标识结束------------------------------------------------
       ------------------------------------基本属性开始------------------------------------------------
       d.F_NAME fmaritalname, --婚姻状况 v_base_maritalstatu
       e.F_NAME fstatusname, --政治面貌 v_base_status
       f.F_NAME feduname, --学历 v_base_edu
       g.F_NAME ffaithname, --宗教信仰 v_base_religion
       h.F_NAME fjobtypename, --职业类别 v_base_jobtype
       i.F_NAME fhjname, --户籍地
       j.F_NAME fxzname, --现住地
       k.F_NAME fyzbzname, --人户一致标志
       ------------------------------------基本属性结束------------------------------------------------

       ------------------------------------户籍人口属性开始------------------------------------------------
       F_FAM_NM, --户名
       F_FAM_M_CARD, --户主公民身份号码
       F_FAM_M_NM, --户主姓名
       l.F_NAME fyhzgxname, --与户主关系
       F_FAM_M_PHONE, --户主联系方式
       F_GOOUTDATE, --外出时间
       F_GOOUTREASON, --外出原因
       m.F_NAME fwcqxname, --外出去向地
       ------------------------------------户籍人口属性结束------------------------------------------------

       ------------------------------------流动人口属性开始------------------------------------------------
       n.F_NAME flryy, --流入原因
       o.F_NAME fbzlx, --办证类型
       F_PAPERS_NUM, --证件号码
       F_REG_DATE, --登记日期
       F_REG_DATE_END, --证件到期日期
       p.F_NAME fzslx --住所类型
       ------------------------------------流动人口属性结束------------------------------------------------

/*       ------------------------------------重点青少年属性开始------------------------------------------------
       u.F_NAME F_MAN_TYPE, --青少年人员类型 v_base_persontype
       v.F_NAME F_FAMI_STAT, --家庭情况 v_base_familytype
       F_SCHOOLNAME, --   学校名称
       r.F_GUAR_REAL, --与监护人关系 v_base_guardianrelation
       r.F_GUAR, --监护人身份证号
       r.F_GUAR_NAME, --监护人姓名
       r.F_GUAR_CONT_WAY, --   监护人联系方式
       r.F_GUAR_LIVE_PLACE, --监护人居住详址
       decode(r.F_IF_CRIME, '1', '是', '0', '否', '否') F_IF_CRIME, --是否违法犯罪  1:是，0：否
       s.F_NAME F_CRIMESITUATION, --违法情况 v_base_criminalsituation
       r.F_HELP_MAN_NAME, --帮扶人姓名
       r.F_HELP_MAN_CONT_WAY, --帮扶人联系方式
       x.F_NAME F_HELP_WAY, --帮扶方式v_base_helptype
       r.f_help_stat,--帮扶情况
       ------------------------------------重点青少年属性结束------------------------------------------------


       ------------------------------------刑满释放人员属性开始------------------------------------------------
        r2.F_RECI,--是否累犯 是：1 否：0
        ar2.F_NAME F_ORI_CHAR,--原罪名 v_base_chargeclass
        r2.F_ORIGI_PRI_TERM,--原判刑期
        r2.F_SER_PRIS_PLAC,--服刑场所
        r2.F_LEAV_PRI_DATE,--出监所日期yyyy-mm-dd
        br2.F_NAME F_DANG_ASSE_TYPE,--	危险性评估类型 v_base_v_base_riskassessmentclass
        r2.F_JOIN_DATE,--衔接日期yyyy-mm-dd
        cr2.F_NAME F_JOIN_STAT,--衔接情况 v_base_linkup
        r2.F_PLACE_DATE,--安置日期yyyy-mm-dd
        r2.F_PLACE_STAT,--安置情况 v_base_resettlement
        r2.F_NO_PLACE_REAS,--			未安置原因
        r2.F_HELP_TEAC_STAT,--帮教情况
        r2.F_IFREC,	--是否重新犯罪  是：1 否：0
        r2.F_RECI_NAME,--	VARCHAR2(100)--重新犯罪罪名
       ------------------------------------刑满释放人员属性结束------------------------------------------------


       ------------------------------------社区矫正人员属性开始------------------------------------------------
        F_COMM_RECT_MAN_NO,--			社区矫正人员编号
        F_ORIG_PRISI_PLACE,--		原羁押场所
        ar3.F_NAME F_RECT_TYPE,--	矫正类别 v_base_correcttype
        br3.F_NAME F_CASE_TYPE,	--案件类别 v_base_case
        F_CHAR_DETAIL,	--	具体罪名
        F_ORIG_JUD_PRIS_TERM,--		原判刑期
        F_ORIG_JUD_BEGI_DATE,--			原判刑开始时间yyyy-mm-dd
        F_ORIGI_JUDG_END_DATE	,--			原判刑结束时间yyyy-mm-dd
        F_RECT_BEG_DATE,--			矫正开始时间yyyy-mm-dd
        F_RECT_END_DATE,--			矫正结束时间yyyy-mm-dd
        cr3.F_NAME F_RECE_WAY,--			接收方式 v_base_receiveway
        dr3.F_NAME F_SISHI_QI,--				四史情况 v_base_sishi
        F_IF_CIDIV,--			是否累惯犯 是：1 否：0
        F_SAN_SHE_QING,--		三涉情况 v_base_sanshe
        F_IF_BUI_RECT_GROUP,--		是否建立矫正小组 是：1 否：0
        er3.F_NAME F_RECT_GRO_M_STAT,--		矫正小组人员组成情况 v_base_correctteamper
        fr3.F_NAME F_RELI_RECT_TYPE,--		解除矫正类型 v_base_correctlift
        F_ESCAPE,--		是否有脱管 是：1 否：0
        F_ESCAPEREASON,--		脱管原因
        F_CHECKESCAPEDETAIL,--	检查监督脱管情况
        F_ESCAPECORRECTDETAIL,--	脱管纠正情况
        F_MISS,--			是否有漏管  是：1 否：0
        F_MISSREASON,--		漏管原因
        F_CHECKMISSDETAIL,--		检查监督漏管原因
        F_MISSCORRECTDETAIL	,--			漏管纠正情况
        F_REWARDPUNISH,--			奖惩情况
        F_PENALTYCHANGE,--		刑罚变更执行情况
        F_RECRIME,--是否重新犯罪  是：1 否：0
        F_RE_CHARGE_DETAIL--		重新犯罪名称
       ------------------------------------社区矫正人员属性结束------------------------------------------------ */



  from t_psn_resident t
  left join v_base_sex a on t.f_sex = a.F_ID
  left join v_base_nation b on t.f_nation = b.F_ID
  left join v_base_regionalism c on t.f_native = c.F_ID
  left join v_Base_maritalstatu d on t.f_marital = d.F_ID
  left join v_base_status e on t.f_politics = e.F_ID
  left join v_base_edu f on t.f_education = f.F_ID
  left join v_base_religion g on t.f_faith = g.F_ID
  left join v_base_jobtype h on t.f_prf_type = h.F_ID
  left join v_base_regionalism i on t.F_REGISTER = i.F_ID
  left join v_base_regionalism j on t.F_ABODE = j.F_ID
  left join v_base_consistent k on t.F_FAM_STATUS = k.F_ID
  left join v_base_guardianrelation l on t.F_FAM_M_REL = l.F_ID
  left join v_base_regionalism m on t.F_GOOUTTO = m.F_ID
  left join v_base_intoreason n on t.F_FLOA_REASON = n.F_ID
  left join v_base_certificatety o on t.F_PAPERS_TYPE = o.F_ID
  left join v_base_housetype p on t.F_ABODE_TYPE = p.F_ID
  left join v_base_grid q on t.f_gridid = q.F_ID

  left join T_YOUN_EMP_TEEN r on t.f_id_card = r.f_id_num     --重点青少年
  left join T_SPEC_COMP_PRISION r2 on t.f_id_card=r2.f_id_num --刑满释放人员
  left join T_SPEC_COMM r3 on t.f_id_card=r3.f_id_num         --社区矫正人员
  left join T_SPEC_PSYCHOSIS r4 on t.f_id_card=r4.f_id_num         --严重精神障碍
  left join T_SPEC_DRUG r5 on t.f_id_card=r5.f_id_num         --吸毒人员
  left join T_SPEC_ADIS r6 on t.f_id_card=r6.f_id_num         --艾滋病人员

/*  left join v_base_criminalsituation s on r.F_CRIMESITUATION = s.F_ID
  left join v_base_persontype u on r.F_MAN_TYPE=u.F_ID
  left join v_base_familytype v on r.F_FAMI_STAT=v.F_ID
  left join v_base_guardianrelation w on r.F_GUAR_REAL=w.F_ID
  left join v_base_helptype x on r.F_GUAR_REAL=x.F_ID

  left join v_base_chargeclass ar2 on r2.F_ORI_CHAR=ar2.F_ID
  left join v_base_riskassessmentclass br2 on r2.F_DANG_ASSE_TYPE=br2.F_ID
  left join v_base_linkup cr2 on r2.F_JOIN_STAT=cr2.F_ID
  left join v_base_resettlement dr2 on r2.F_PLACE_STAT=dr2.F_ID

  left join v_base_correcttype ar3 on r3.F_RECT_TYPE=ar3.F_ID
  left join v_base_case br3 on r3.F_CASE_TYPE=br3.F_ID
  left join v_base_receiveway cr3 on r3.F_RECE_WAY=cr3.F_ID
  left join v_base_sishi dr3 on r3.F_SISHI_QI=dr3.F_ID
  left join v_base_correctteamper er3 on r3.F_RECT_GRO_M_STAT=er3.F_ID
  left join v_base_correctlift fr3 on r3.F_RELI_RECT_TYPE=fr3.F_ID*/


 where t.f_visable = 1
/
