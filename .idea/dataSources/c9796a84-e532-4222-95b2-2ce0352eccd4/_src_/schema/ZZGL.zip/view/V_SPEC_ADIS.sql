CREATE VIEW V_SPEC_ADIS AS select t.*,
z.f_name zfname,--户籍人口表数据的开始
z.f_name_his zfnamehis,
z.f_sex zfsex,
z.f_id_card zfidcard,
z.f_birthday zfbirthday,
z.f_nation zfnation,
z.f_native zfnative,
z.f_marital zfmarital,
z.f_politics zpolitics,
z.f_education zfeduation,
z.f_faith   zffaith,
z.f_prf_type zfprftype,
z.f_profession zfprofession,
z.f_sev_place zfserplace,
z.f_phone zfphone,
z.F_REGISTER zfregister,
z.f_register_adrs zfregisteradrs,
z.F_ABODE zfabode,
z.F_ABODE_ADRS zfaboeadrs,
z.fsexname,
z.fnationname,
z.fnativename,
z.fmaritalname,
z.fstatusname,
z.feduname,
z.ffaithname,
z.fjobtypename,
z.fhjname,
z.fxzname,
z.f_native_name,
z.f_hjname,
z.f_xzname,--户籍人口表数据结束
a.F_NAME fgrtj,--感染途径
b.F_NAME fajlb,--案件类别
c.F_NAME fgzlx,--关注类型
d.F_NAME fszqk,--收治情况
e.f_grid_nm fgridname,--网格名称
z.f_x,z.f_y,z.f_gisid
from t_spec_adis t
left join v_psn_resident z on t.f_id_num=z.f_id_card
left join v_base_infection a on t.F_INFECT_WAY=a.F_ID
left join v_base_case b on t.F_CASE_TYPE=b.F_ID
left join v_base_focusty c on t.F_ATTEN_YPE=c.F_ID
left join  v_base_receiveandcure d on t.F_CURE_STATUS=d.F_ID
left join  t_base_grid  e on t.f_gridid=e.f_id
where t.f_visable=1
/
