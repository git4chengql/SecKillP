CREATE VIEW V_BASE_NETWORK AS select t.*,
a.F_NAME flvlname,
b.F_NAME fcityname,
c.f_grid_nm fgridname
from t_base_network t
left join v_base_level a on t.f_netw_lvl=a.F_ID
left join v_base_regionalism b on t.f_city=b.F_ID
left join t_base_grid c on t.f_gridid=c.f_id

    where t.f_visable=1
/
