CREATE VIEW V_BASE_LEADER AS select  t.*,a.f_grid_nm fgridname, b.F_NAME flevelname,c.F_NAME fentyname ,d.F_NAME fpplyname
from t_base_lerder t
left join  T_BASE_GRID a on t.f_gridid=a.f_id
left join  v_base_level b on t.F_AREA_LVL=b.F_ID
left join  v_base_level c on t.f_enty_lvl=c.F_ID
left join v_base_policytype d on t.f_pply_type=d.F_ID
/
