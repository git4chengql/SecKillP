CREATE VIEW V_BASE_MASS AS select t.f_id,t.F_ORG_NM,t.F_NAME,t.F_SEX,t.F_NATION,t.F_STATUS,t.F_IDCARD,t.F_BIRTH_DT,t.F_DUTY,t.F_EDU,t.F_PHONE,t.F_TEL,t.F_IDTYPE,t.f_creatdate,t.F_SPECIALTY,t.F_GRIDID,t.F_VISABLE,
 a.F_NAME f_sex_name, b.F_NAME f_nation_name,
 c.F_NAME f_status_name, d.F_NAME f_edu_name,
 e.F_NAME f_specialty_name,f.F_NAME f_idtype_name,
 g.f_org_nm f_org_nm_name,h.f_grid_nm f_gridid_name,
 t.f_region,
 t.f_region_name
 from T_BASE_MASS t
 left join V_base_SEX  a on t.f_sex= a.F_ID
 left join V_base_nation  b on t.f_nation= b.F_ID
 left join v_base_status  c on t.f_status= c.F_ID
 left join v_base_edu  d on t.f_edu= d.F_ID
 left join v_base_Specialty e on t.f_specialty= e.F_ID
 left join v_base_identificationcode f on t.f_idtype= f.F_ID
 left join t_base_mass_org g on t.f_org_nm= g.F_ID
 left join t_base_grid h on t.f_gridid= h.F_ID
 where t.f_visable=1
/
