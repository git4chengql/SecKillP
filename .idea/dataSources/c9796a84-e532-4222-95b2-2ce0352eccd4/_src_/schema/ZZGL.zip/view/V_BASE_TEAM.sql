CREATE VIEW V_BASE_TEAM AS select t.f_id,t.f_org_nm,t.f_name,
    t.f_sex,t.f_nation,
    t.f_status,t.f_idcard,
    t.f_birth_dt,t.f_grade,t.f_duty,
    t.f_educate,t.f_phone,t.f_tel,
    t.f_specialty,
    t.f_gridid,
    t.f_region,
    t.f_region_name,
    a.F_NAME fsexname,
     b.F_NAME fdutyname,
    c.F_NAME feduname,d.F_NAME fgradename,
    e.F_NAME fnationname,f.F_NAME fstatusname,
    g.f_org_nm fszjgname,
    s.f_grid_nm fgridname
    from t_base_team t
    left join v_base_sex  a on t.f_sex= a.F_ID
    left join v_base_duty b on t.f_duty=b.F_ID
    left join v_base_edu  c on t.f_educate=c.F_ID
    left join v_base_grade d on t.f_grade=d.F_ID
    left join v_base_nation e on t.f_nation=e.F_ID
    left join v_base_status f on t.f_status=f.F_ID
    left join t_base_org g on t.f_org_nm=g.f_id
    left join t_base_grid s on t.f_gridid=s.f_id
    where t.f_visable=1
/
