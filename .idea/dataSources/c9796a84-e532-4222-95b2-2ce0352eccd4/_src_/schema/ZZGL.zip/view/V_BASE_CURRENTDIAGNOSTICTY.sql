CREATE VIEW V_BASE_CURRENTDIAGNOSTICTY AS select "F_ID","F_TYPE","F_CODE","F_NAME","F_NOTE1","F_NOTE2","F_NOTE3","F_PCODE","FCREATDATE"
    from t_base_code where f_type='628'


 /*  目前诊断类型*/
/
