CREATE VIEW VACT_HI_ACTINST AS select tc.call_proc_inst_id_ nodeName,
                     to_char(t1.f_createtime, 'YYYY-MM-DD HH24:MI:SS') startTime,
                     to_char(t1.f_createtime, 'YYYY-MM-DD HH24:MI:SS') endTime,
                     h0.humandesc assigner,
                     t1.f_feedbck note,
                     a0.noteimg noteImg,
                     tc.proc_Inst_Id_
                from ACT_HI_ACTINST tc
                left join act_ru_execution t0
                  on tc.execution_id_ = t0.proc_inst_id_
                left join t_ver_task t1
                  on t0.business_key_ = t1.f_evt_no
                 left join tcHuman h0
                  on t1.f_taskpeo = h0.humanid
                left join t_Act_Note a0
                  on tc.Task_Id_ = a0.taskid
               where tc.act_type_ != 'startEvent'
                 and tc.end_time_ is not null
/
