CREATE VIEW V_SECU_KEYAREAS AS select t.F_ID,t.F_KEY_AREAS,t.F_SECURITY_PROBLEMS,t.F_REGIONA_TYPE,t.F_REGIONA_AREA,t.F_LED_UNITS,t.F_IN_UNITS,t.F_LEAD_NAME,t.F_LEAD_CONTACT,t.F_RECT_LIMIT,t.F_SOLVE_CRIMINAL,t.F_PERIOD_CRIMINAL,t.F_REGULATION,t.F_EVALUATION,t.F_CREATDATE,t.F_GRIDID,t.F_VISABLE,
a.F_NAME f_security_problems_name, b.F_NAME f_regiona_type_name,
c.F_NAME f_evaluation_name,d.f_grid_nm f_gridid_name
from T_SECU_KEYAREAS t
left join v_base_securityproblem  a on t.f_security_problems= a.F_ID
left join v_base_involvearea  b on t.f_regiona_type= b.F_ID
left join v_base_evaluation  c on t.f_evaluation= c.F_ID
left join t_base_grid  d on t.f_gridid= d.F_ID
where t.f_visable=1
/
