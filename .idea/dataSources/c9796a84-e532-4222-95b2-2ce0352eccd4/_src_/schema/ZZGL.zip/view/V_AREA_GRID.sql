CREATE VIEW V_AREA_GRID AS select
  m.fid,
  m.areaname,
  m.parentid,
  1 isGrid
from t_Base_Area m

union all

select
 g.f_id fid,
 g.f_grid_nm areaName,
 g.f_areaid parentid,
 0 isGrid
from t_Base_Grid g
/
