CREATE VIEW V_PSN_DETAIL_MAIN AS select
        t.F_FLOATFLAG ffloatflagval ,--人员类型标志   户籍或者流动
        nvl(t.F_LSRY,0) flsryval,--留守人员标志
        nvl(t.F_XMSF,0) fxmsfval,--刑满释放人员标志
        nvl(t.F_SQJZ,0) fsqjzval,--社区矫正人员标志
        nvl(t.F_JSZA,0) fjszaval,--精神障碍人员标志
        nvl(t.F_XDRY,0) fxdryval,--吸毒人员标志
        nvl(t.F_AIDS,0) faidsval,--艾滋病人员标志
        nvl(t.F_ZDQSN,0) fzdqsnval,--重点青少年标志
       t.f_gridid, --所属网格ID
       q.f_grid_nm, --所属网格名称
       t.f_id, --主键
       t.f_id_card, --身份证号
       t.f_name, --姓名
       t.f_name_his,--曾用名
       t.f_birthday,--出生日期
       t.f_profession,--职业
       t.f_sev_place,--服务处所
       t.f_phone,--联系方式
       t.F_REGISTER_ADRS,--户籍楼门详址,
       t.F_ABODE_ADRS,--现住楼门详址
       t.F_ABODE,--现住地
       t.F_PHOTO, --照片
       t.f_imgname,--图片名称
       a.F_NAME fsexname, --性别 v_base_sex
       t.f_sex,     --性别id
       b.F_NAME fnationname, --民族 v_base_nation
       t.f_nation,  --民族id
       c.F_NAME fnativename, --籍贯 v_base_regionalism
       t.f_native,  --籍贯id
       t.f_hjname,--户籍
       t.f_xzname,--现住
       t.f_native_name,--籍贯
       ------------------------------------状态标识开始------------------------------------------------
       decode(t.f_attention_yn, 1, '重点关注人员', 0, '', '') f_attention_yn, --重点关注人员
       decode(t.f_floatflag, 1, '流动人口', 0, '户籍人口', '户籍人口') f_floatflag, --数据类别
       decode(t.f_lsry, 1, '留守人员', 0, '', '') f_lsry,
       decode(t.f_xmsf, 1, '刑满释放人员', 0, '', '') f_xmsf,
       decode(t.f_sqjz, 1, '社区矫正', 0, '', '') f_sqjz,
       decode(t.f_jsza, 1, '精神障碍', 0, '', '') f_jsza,
       decode(t.f_xdry, 1, '留守人员', 0, '', '') f_xdry,
       decode(t.f_aids, 1, '艾滋人员', 0, '', '') f_aids,
       decode(t.f_zdqsn, 1, '重点青少年', 0, '', '') f_zdqsn,
       ------------------------------------状态标识结束------------------------------------------------
       ------------------------------------基本属性开始------------------------------------------------
       d.F_NAME fmaritalname, --婚姻状况 v_base_maritalstatu
       t.f_marital, --婚姻状况id
       e.F_NAME fstatusname, --政治面貌 v_base_status
       t.f_politics, --政治面貌id
       f.F_NAME feduname, --学历 v_base_edu
       t.f_education,  -- 学历id
       g.F_NAME ffaithname, --宗教信仰 v_base_religion
       t.f_faith,   --宗教信仰id
       h.F_NAME fjobtypename, --职业类别 v_base_jobtype
       t.f_prf_type, --职业类别id
       t.f_register,
       i.F_NAME fhjname, --户籍地
       j.F_NAME fxzname, --现住地
       k.F_NAME fyzbzname, --人户一致标志
       ------------------------------------基本属性结束------------------------------------------------
       ------------------------------------户籍人口属性开始------------------------------------------------
       t.F_FAM_NM, --户名
       t.F_FAM_M_CARD, --户主公民身份号码
       t.F_FAM_M_NM, --户主姓名
       t.f_fam_m_rel,
       l.F_NAME fyhzgxname, --与户主关系
       t.F_FAM_M_PHONE, --户主联系方式
       t.F_GOOUTDATE, --外出时间
       t.F_GOOUTREASON, --外出原因
       m.F_NAME fwcqxname, --外出去向地
       ------------------------------------户籍人口属性结束------------------------------------------------
       ------------------------------------流动人口属性开始------------------------------------------------
       t.F_FLOA_REASON,--流入原因id
       n.F_NAME flryy, --流入原因
       o.F_NAME fbzlx, --办证类型
       F_PAPERS_NUM, --证件号码
       t.F_REG_DATE, --登记日期
       F_REG_DATE_END, --证件到期日期
       p.F_NAME fzslx, --住所类型
       ------------------------------------流动人口属性结束------------------------------------------------
       t.f_houseid, --居住房屋ID T_PSN_HOUSE.F_ID
       r.f_buildid f_buildid, --所属楼栋id
       u.f_x,u.f_y,u.f_gisid,y.f_name f_hzname
  from t_psn_resident t
  left join v_base_sex a on t.f_sex = a.F_ID
  left join v_base_nation b on t.f_nation = b.F_ID
  left join v_base_regionalism c on t.f_native = c.F_ID
  left join v_Base_maritalstatu d on t.f_marital = d.F_ID
  left join v_base_status e on t.f_politics = e.F_ID
  left join v_base_edu f on t.f_education = f.F_ID
  left join v_base_religion g on t.f_faith = g.F_ID
  left join v_base_jobtype h on t.f_prf_type = h.F_ID
  left join v_base_regionalism i on t.F_REGISTER = i.F_ID
  left join v_base_regionalism j on t.F_ABODE = j.F_ID
  left join v_base_consistent k on t.F_FAM_STATUS = k.F_ID
  left join v_base_guardianrelation l on t.F_FAM_M_REL = l.F_ID
  left join v_base_regionalism m on t.F_GOOUTTO = m.F_ID
  left join v_base_intoreason n on t.F_FLOA_REASON = n.F_ID
  left join v_base_certificatety o on t.F_PAPERS_TYPE = o.F_ID
  left join v_base_housetype p on t.F_ABODE_TYPE = p.F_ID
  left join v_base_grid q on t.f_gridid = q.F_ID
  left join T_PSN_HOUSE r on t.f_houseid = r.F_ID
  left join t_psn_house s on s.f_id=t.f_houseid
  left join t_base_buildadm u on u.f_id=s.f_buildid
  left join t_psn_resident y on y.f_id=t.f_fam_m_nm
/
