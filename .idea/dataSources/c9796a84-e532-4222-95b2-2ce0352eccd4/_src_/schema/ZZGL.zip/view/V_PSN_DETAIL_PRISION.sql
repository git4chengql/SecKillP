CREATE VIEW V_PSN_DETAIL_PRISION AS select t.f_gridid, --所属网格ID
       q.f_grid_nm, --所属网格名称
       t.f_id, --主键
       t.f_id_card, --身份证号
       t.f_name, --姓名
       t.fsexname,--性别
       t.fnationname,--民族
       t.fxzname,--住址
       t.F_PHOTO, --照片
       ------------------------------------状态标识开始------------------------------------------------
       decode(t.f_attention_yn, 1, '重点关注人员', 0, '', '') f_attention_yn, --重点关注人员
       decode(t.f_floatflag, 1, '流动人口', 0, '户籍人口', '户籍人口') f_floatflag, --数据类别
       decode(t.f_lsry, 1, '留守人员', 0, '', '') f_lsry,
       decode(t.f_xmsf, 1, '刑满释放人员', 0, '', '') f_xmsf,
       decode(t.f_sqjz, 1, '社区矫正', 0, '', '') f_sqjz,
       decode(t.f_jsza, 1, '精神障碍', 0, '', '') f_jsza,
       decode(t.f_xdry, 1, '留守人员', 0, '', '') f_xdry,
       decode(t.f_aids, 1, '艾滋人员', 0, '', '') f_aids,
       decode(t.f_zdqsn, 1, '重点青少年', 0, '', '') f_zdqsn,
       ------------------------------------状态标识结束------------------------------------------------

       ------------------------------------刑满释放人员属性开始------------------------------------------------
        r2.F_RECI,--是否累犯 是：1 否：0
        r2.F_ORI_CHAR,--原罪名id
        ar2.F_NAME F_ORI_CHARname,--原罪名 v_base_chargeclass
        r2.F_ORIGI_PRI_TERM,--原判刑期
        r2.F_SER_PRIS_PLAC,--服刑场所
        r2.F_LEAV_PRI_DATE,--出监所日期yyyy-mm-dd
        r2.F_DANG_ASSE_TYPE,--危险性评估类型id
        br2.F_NAME F_DANG_ASSE_TYPEname,--	危险性评估类型 v_base_v_base_riskassessmentclass
        r2.F_JOIN_DATE,--衔接日期yyyy-mm-dd
        r2.F_JOIN_STAT,--衔接情况id
        cr2.F_NAME F_JOIN_STATname,--衔接情况 v_base_linkup
        r2.F_PLACE_DATE,--安置日期yyyy-mm-dd
        r2.F_PLACE_STAT,--安置情况id
        dr2.F_NAME F_PLACE_STATname,--安置情况 v_base_resettlement
        r2.F_NO_PLACE_REAS,--			未安置原因
        r2.F_HELP_TEAC_STAT,--帮教情况
        r2.F_IFREC,	--是否重新犯罪  是：1 否：0
        r2.F_RECI_NAME--	VARCHAR2(100)--重新犯罪罪名
       ------------------------------------刑满释放人员属性结束------------------------------------------------


  from v_psn_resident t
  left join v_base_grid q on t.f_gridid = q.F_ID
  left join T_SPEC_COMP_PRISION r2 on t.f_id_card=r2.f_id_num --刑满释放人员
  left join v_base_chargeclass ar2 on r2.F_ORI_CHAR=ar2.F_ID
  left join v_base_riskassessmentclass br2 on r2.F_DANG_ASSE_TYPE=br2.F_ID
  left join v_base_linkup cr2 on r2.F_JOIN_STAT=cr2.F_ID
  left join v_base_resettlement dr2 on r2.F_PLACE_STAT=dr2.F_ID




 where t.f_visable = 1
/
