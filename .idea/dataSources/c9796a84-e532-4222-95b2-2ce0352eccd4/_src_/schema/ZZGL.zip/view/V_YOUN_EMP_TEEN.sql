CREATE VIEW V_YOUN_EMP_TEEN AS select t.*,
z.f_name zfname,--户籍人口表数据的开始
z.f_name_his zfnamehis,
z.f_sex zfsex,
z.f_id_card zfidcard,
z.f_birthday zfbirthday,
z.f_nation zfnation,
z.f_native zfnative,
z.f_marital zfmarital,
z.f_politics zpolitics,
z.f_education zfeduation,
z.f_faith   zffaith,
z.f_prf_type zfprftype,
z.f_profession zfprofession,
z.f_sev_place zfserplace,
z.f_phone zfphone,
z.F_REGISTER zfregister,
z.f_register_adrs zfregisteradrs,
z.F_ABODE zfabode,
z.F_ABODE_ADRS zfaboeadrs,
z.fsexname,
z.fnationname,
z.fnativename,
z.fmaritalname,
z.fstatusname,
z.feduname,
z.ffaithname,
z.fjobtypename,
z.fhjname,
z.fxzname,
z.f_native_name,
z.f_hjname,
z.f_xzname,--户籍人口表数据结束
a.f_name f_fami_stat_name,
b.F_NAME f_foucslevel_name,
c.F_NAME f_crimesituation_name,
d.f_name f_schoolev_name,
e.f_name f_magtype_name,
f.f_name f_crimetype_name,
h.f_name f_help_way_name,
m.f_grid_nm fgridname,
n.F_NAME f_guar_real_name,
z.f_x,z.f_y,z.f_gisid
from t_youn_emp_teen t
left join v_psn_resident z on t.f_id_num=z.f_id_card
left join v_base_familytype a on t.F_FAMI_STAT=a.f_id
left join v_base_focuslevel b on t.F_FOUCSLEVEL=b.F_ID
left join v_base_criminalsituation c on t.F_CRIMESITUATION=c.f_id
left join v_base_level d on t.F_SCHOOLEV =d.f_id
left join v_base_managetool e on t.F_MAGTYPE=e.F_ID
left join v_base_criminaltype f on t.F_CRIMETYPE=f.F_ID
left join v_base_helptype h on t.F_HELP_WAY=h.f_id
left join t_base_grid m on t.F_GRIDID = m.f_id
left join v_base_guardianrelation n on t.F_GUAR_REAL=n.F_ID
/
