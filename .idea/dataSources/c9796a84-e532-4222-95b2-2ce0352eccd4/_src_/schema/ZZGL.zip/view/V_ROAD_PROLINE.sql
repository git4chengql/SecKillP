CREATE VIEW V_ROAD_PROLINE AS select t.*,a.f_name fdistrictname,b.F_NAME fdanglvlname,c.f_grid_nm fgridname
    from t_road_proline t
    left join v_base_linetype a on t.f_district=a.F_ID
    left join v_base_securitydangelev b on t.f_danger_lv=b.F_ID
    left join t_base_grid c on t.f_gridid=c.f_id
    where t.f_visable=1
/
