CREATE VIEW V_SECU_JDWLAQGL AS select t.F_ID,t.F_BUSINESSLICENSENUMBER,t.F_SENDENTERPRISENAME,t.F_LOCUS,t.F_LOCUSADDRESS,t.F_FIRMTELEPHONE,t.F_FIRMDIRECTORNAME,t.F_FIRMDIRECTORTELEPHONE,t.F_REGISTRATIONTYPE,t.F_HOLDINGSITUATION,t.F_BUSINESSSCOPE,t.F_ENTERPRISETYPE,t.F_SERVICEBRAND,t.F_EMPLOYEESNUMBER,t.F_CAMERANUMBER,t.F_XRAYMACHINENUMBER,t.F_CHECKANDCLOSE,t.F_SENDBYREALNAME,t.F_XRAYCHECK,t.F_X,t.F_Y,t.F_CREATDATE,t.F_GRIDID,t.F_VISABLE,t.locusname,
a.F_NAME f_locus_name, b.F_NAME f_registrationtype_name,
c.F_NAME f_holdingsituation_name, d.F_NAME f_businessscope_name,
e.F_NAME f_enterprisetype_name,
(case t.f_checkandclose
when 0 then '否'
when 1 then '是'
else '未知'
end) as f_checkandclose_name,
(case t.f_sendbyrealname
when 0 then '否'
when 1 then '是'
else '未知'
end) as f_sendbyrealname_name,
(case t.f_xraycheck
when 0 then '否'
when 1 then '是'
else '未知'
end) as f_xraycheck_name,
f.f_grid_nm f_gridid_name
from T_SECU_JDWLAQGL t
left join v_base_regionalism  a on t.f_locus= a.F_ID
left join v_base_registrationtype  b on t.f_registrationtype= b.F_ID
left join v_base_hold  c on t.f_holdingsituation= c.F_ID
left join v_base_businessscope  d on t.f_businessscope= d.F_ID
left join v_base_companyform  e on t.f_enterprisetype= e.F_ID
left join t_base_grid  f on t.f_gridid= f.F_ID
where t.f_visable=1
/
