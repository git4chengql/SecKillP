CREATE VIEW V_BASE_SEX AS select "F_ID","F_TYPE","F_CODE","F_NAME","F_NOTE1","F_NOTE2",
"F_NOTE3","F_PCODE" from t_base_code where f_type = '78'
/
