CREATE VIEW V_LOG AS select t.*,a.humanname humanname from t_log t
left join tchuman a on t.f_humanid=a.humanid
order by t.f_creatdate desc
/
