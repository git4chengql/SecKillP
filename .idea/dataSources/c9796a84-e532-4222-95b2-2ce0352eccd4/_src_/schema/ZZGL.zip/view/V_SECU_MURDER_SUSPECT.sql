CREATE VIEW V_SECU_MURDER_SUSPECT AS select t.F_ID,t.F_CASEID,t.F_IDCARD,t.F_NAME,t.F_FOEMER_NAME,t.F_SEX,t.F_BIRTHDATE,t.F_NATIONAL,t.F_NATIVEPLACE,t.F_MARITAL_STATUS,t.F_FACE,t.F_EDU,t.F_BELIEFS,t.F_PROCATE,t.F_PROFESSIONAL,t.F_PREMISES,t.F_DOMICILE,t.F_DETAILADDR,t.F_NOWADDR,t.F_DETAILADDR_NOW,t.F_PATIENTS,t.F_MINORS,t.F_TEENAGERS,t.F_NATIONALITY,t.F_CREATDATE,t.F_CARDID,t.F_CARDNUM,t.F_GRIDID,t.F_VISABLE,t.f_jg_native,t.f_hj_register,t.f_xzd_abode,
a.F_NAME f_sex_name, b.F_NAME f_national_name,
c.F_NAME f_nativeplace_name, d.F_NAME f_marital_status_name,
e.F_NAME f_face_name, f.F_NAME f_edu_name,
g.F_NAME f_beliefs_name, h.F_NAME f_procate_name,
i.F_NAME f_domicile_name, j.F_NAME f_nowaddr_name,
k.F_NAME f_nationality_name,
(case t.f_patients
when 0 then '否'
when 1 then '是'
else '未知'
end) as f_patients_name,
(case t.f_minors
when 0 then '否'
when 1 then '是'
else '未知'
end) as f_minors_name,
(case t.f_teenagers
when 0 then '否'
when 1 then '是'
else '未知'
end) as f_teenagers_name,
l.f_grid_nm f_gridid_name
from T_SECU_MURDER_SUSPECT t
left join v_base_sex  a on t.f_sex= a.F_ID
left join v_base_nation  b on t.f_national= b.F_ID
left join v_base_regionalism  c on t.f_nativeplace= c.F_ID
left join v_base_maritalstatu  d on t.f_marital_status= d.F_ID
left join v_base_status  e on t.f_face= e.F_ID
left join v_base_edu  f on t.f_edu= f.F_ID
left join v_base_religion  g on t.f_beliefs= g.F_ID
left join v_base_jobtype  h on t.f_procate= h.F_ID
left join v_base_regionalism  i on t.f_domicile= i.F_ID
left join v_base_regionalism  j on t.f_nowaddr= j.F_ID
left join v_base_nationality  k on t.f_nationality= k.F_ID
left join t_base_grid  l on t.f_gridid= l.F_ID
where t.f_visable=1
/
