CREATE VIEW V_MSG AS select t."F_ID",t."F_TITLE",t."F_BODY",t."F_HUMANID",t."F_STATUS",t."F_CREATDATE" from T_MSG t
/
