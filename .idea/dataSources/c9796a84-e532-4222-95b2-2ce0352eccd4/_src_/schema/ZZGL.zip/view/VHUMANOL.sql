CREATE VIEW VHUMANOL AS select a.humanid,a.humandesc humanname,a.gridname,a.gridid F_GRIDID,a.telmobile,a.f_imgname,(CASE WHEN b.f_id is null THEN '离线' else '在线' END) as ol,(case when to_char(sysdate,'yyyy-mm-dd')=to_char(c.f_check_date,'yyyy-mm-dd') then to_char(c.f_check_date,'hh24:mi:ss') else '今日未打卡' end) f_check_date,
d.f_x,d.f_y from
(select * from vchuman t where t.roleid=1 and t.gridid is not null) a
left join (select * from t_check_online where to_char(sysdate,'yyyy-mm-dd')=to_char(F_CREATDATE,'yyyy-mm-dd')) b on a.humanid=b.f_humanid
left join (select s.f_humanid,max(s.f_check_date) f_check_date from t_work_checkin s where s.f_check_type=0 group by s.f_humanid) c on a.humanid=c.f_humanid
left join (select  f_humanid,f_x,f_y
from ( select f_humanid,f_x,f_y,row_number() over(partition by f_humanid order by f_work_date desc) rn
  from t_work_patrol where to_char(sysdate,'yyyy-mm-dd')=to_char(F_WORK_DATE,'yyyy-mm-dd')) t where rn=1) d on d.f_humanid=a.humanid
/
