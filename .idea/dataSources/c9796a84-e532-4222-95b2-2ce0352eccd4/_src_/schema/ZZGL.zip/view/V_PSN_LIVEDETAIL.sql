CREATE VIEW V_PSN_LIVEDETAIL AS select t.*,b.F_NAME sexname,c.F_NAME nationname,d.F_NAME regionalism,e.F_NAME maritalname,f.F_NAME politicsname,g.F_NAME faithname , h.F_NAME educatname,
i.F_NAME typename,j.F_NAME registername,k.f_name livename,a.f_hou_id houseid
from T_PSN_LIVEDETAIL t
left join t_psn_house a on t.f_houseid=a.F_ID
left join v_base_sex b on t.f_sex=b.F_ID
left join v_base_nation c on t.f_nation=c.F_ID
left join v_base_regionalism d on t.f_native=d.F_ID
left join v_Base_maritalstatu e on t.f_marital=e.F_ID
left join v_base_status f on t.f_politics=f.F_ID
left join v_base_religion g on t.f_faith=g.F_ID
left join v_base_edu h on t.f_education=h.F_ID
left join v_base_jobtype i on t.f_prf_type=i.F_ID
left join v_base_regionalism j on t.f_register=j.F_ID
left join T_PSN_RESIDENT k on t.f_livepsnid=k.F_ID
/
