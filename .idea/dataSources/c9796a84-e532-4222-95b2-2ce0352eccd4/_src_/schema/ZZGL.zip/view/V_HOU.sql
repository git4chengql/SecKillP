CREATE VIEW V_HOU AS select f_id,f_name,t.f_gridid,t.f_id_card
    from t_psn_resident t
    where t.f_Fam_m_Rel='3755'
/
