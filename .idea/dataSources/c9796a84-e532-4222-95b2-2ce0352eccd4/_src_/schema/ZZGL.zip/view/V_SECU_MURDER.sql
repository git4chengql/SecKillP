CREATE VIEW V_SECU_MURDER AS select t.F_ID,t.F_CASENAME,t.F_CASENUM,t.F_BOTHTIME,t.F_SOLVETIME,t.F_BRIEF,t.F_GRIDID,t.F_VISABLE,
a.f_grid_nm f_gridid_name
from T_SECU_MURDER t
left join t_base_grid a on t.f_gridid=a.f_id
where t.f_visable=1
/
