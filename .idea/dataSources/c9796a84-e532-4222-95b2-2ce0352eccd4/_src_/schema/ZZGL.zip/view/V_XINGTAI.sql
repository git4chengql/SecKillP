CREATE VIEW V_XINGTAI AS select "FID","AREACODE","AREANAME","PARENTCODE","CREATEDATE","PARENTID"
    from T_BASE_AREA
   where parentid=808 or fid=808 or parentid in (select "FID"
    from T_BASE_AREA
   where parentid in (select "FID"
    from T_BASE_AREA
   where parentid=808))
/
