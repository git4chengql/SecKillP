CREATE VIEW V_UNIONPHO AS select recid,wmsys.wm_concat(medianame) as medianame,t.f_taskpeo,t.createdate from t_rec_media  t
where t.state=1
  group by recid,f_taskpeo,createdate
/
