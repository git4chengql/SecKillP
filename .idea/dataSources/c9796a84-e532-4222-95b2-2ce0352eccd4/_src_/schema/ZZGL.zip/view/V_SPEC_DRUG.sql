CREATE VIEW V_SPEC_DRUG AS select t.*,
a.f_grid_nm fgridname,--所属网络的名称
z.fsexname,--视图主表中的字段开始
z.fnationname,
z.fnativename,
z.fmaritalname,
z.fstatusname,
z.feduname,
z.ffaithname,
z.fjobtypename,
z.fhjname,
z.fxzname,
z.f_native_name,
z.f_hjname,
z.f_xzname,--结束
s.F_NAME fgkqk,--管控情况
k.F_NAME fdrugresname,--吸毒人员的特性 吸毒原因
l.F_NAME fdrugeffname,--吸毒后果
z.f_name zfname,--以下读取主表的信息
z.f_name_his zfnamehis,--曾用名
z.f_sex zfsex,
z.f_id_card zfidcard,
z.f_birthday zfbirthday,
z.f_nation zfnation,
z.f_native zfnative,
z.f_marital zfmarital,
z.f_politics zpolitics,
z.f_education zfeduation,
z.f_faith   zffaith,
z.f_prf_type zfprftype,
z.f_profession zfprofession,
z.f_sev_place zfserplace,
z.f_phone zfphone,
z.F_REGISTER zfregister,
z.f_register_adrs zfregisteradrs,
z.F_ABODE zfabode,
z.F_ABODE_ADRS zfaboeadrs,
z.f_x,z.f_y,z.f_gisid
from T_SPEC_DRUG  t
left join v_base_drugreason k on t.F_DRUG_REASON=k.F_ID
left join v_base_drugconsequence l on t.F_DRUG_EFFECT=l.F_ID
left join  v_base_control s on t.F_CONT_STATUS=s.F_ID
left join v_psn_resident  z on  t.f_id_num=z.f_id_card
left join T_BASE_GRID a on  t.f_gridid=a.f_id
where t.f_visable=1
/
