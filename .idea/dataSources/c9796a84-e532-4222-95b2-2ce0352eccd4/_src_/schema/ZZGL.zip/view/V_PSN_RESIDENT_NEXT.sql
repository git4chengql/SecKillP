CREATE VIEW V_PSN_RESIDENT_NEXT AS select "F_ID","F_NAME"
    from t_psn_resident
/
