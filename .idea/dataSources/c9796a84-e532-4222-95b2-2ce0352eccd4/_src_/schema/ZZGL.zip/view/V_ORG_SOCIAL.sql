CREATE VIEW V_ORG_SOCIAL AS select t.F_ID,t.F_REGNUM,t.F_ORGNAME,t.F_MANCODE,t.F_LEGALMAN,t.F_RESIDENCE,t.F_APPROVALDATE,t.F_ORGTYPE,t.F_STATE,t.F_HEADCODE,t.F_HEADNUM,t.F_HEADNAME,t.F_HEADCONTACT,t.F_OFFICE,t.F_SECURITY_NAME,t.F_SECURITY_CONTACT,t.F_ATTENTION,t.F_HAVE_CONDITION,t.F_HAVE_ORG,t.F_PARTY_NUM,t.F_HAVE_UNION,t.F_UNION_NUM,t.F_HAVE_YOUTH,t.F_YOUTH_NUM,t.F_HAVE_WOMEN,t.F_WOMEN_NUM,t.F_MONEY_SOURCES,t.F_BACKGROUND,t.F_X,t.F_Y,t.F_CREATDATE,t.F_GRIDID,t.F_VISABLE,t.f_credit,t.f_imgname,
t.F_GISID,
a.F_NAME f_orgtype_name, b.F_NAME f_headcode_name,
c.F_NAME f_attention_name,
(case t.f_have_condition
when 0 then '否'
when 1 then '是'
else '未知'
end) as f_have_condition_name,
(case t.f_have_org
when 0 then '否'
when 1 then '是'
else '未知'
end) as f_have_org_name,
(case t.f_have_union
when 0 then '否'
when 1 then '是'
else '未知'
end) as f_have_union_name,
(case t.f_have_youth
when 0 then '否'
when 1 then '是'
else '未知'
end) as f_have_youth_name,
(case t.f_have_women
when 0 then '否'
when 1 then '是'
else '未知'
end) as f_have_women_name,
(case t.f_background
when 0 then '否'
when 1 then '是'
else '未知'
end) as f_background_name,
d.f_grid_nm f_gridid_name
from T_ORG_SOCIAL t
left join v_base_socialorgtype  a on t.f_orgtype= a.F_ID
left join v_base_identificationcode  b on t.f_headcode= b.F_ID
left join v_base_focuslevel  c on t.f_attention= c.F_ID
left join t_base_grid d on t.f_gridid= d.F_ID
where t.f_visable=1
/
