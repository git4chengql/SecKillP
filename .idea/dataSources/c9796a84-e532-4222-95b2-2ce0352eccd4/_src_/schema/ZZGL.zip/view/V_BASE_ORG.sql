CREATE VIEW V_BASE_ORG AS select t.f_id,t.f_org_nm,t.f_org_type,t.f_gridid,
t.f_org_lvl,t1.F_NAME f_levelname,
t2.F_NAME f_typename,
t3.f_grid_nm fgridname,
t.f_region,t.f_region_name
from t_base_org t
left join v_base_level t1 on  t.f_org_lvl=t1.F_ID
left join v_base_type  t2 on t.f_org_type=t2.F_ID
left join T_BASE_GRID t3 on t.f_gridid=t3.f_id
where t.f_visable=1
/
