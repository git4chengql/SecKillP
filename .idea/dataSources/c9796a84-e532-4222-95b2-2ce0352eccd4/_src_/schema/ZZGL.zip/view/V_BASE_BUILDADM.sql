CREATE VIEW V_BASE_BUILDADM AS select t.*,
a.F_NAME f_sex_name, b.F_NAME f_nation_name,
c.F_NAME f_politics_name, d.F_NAME f_edu_name,
e.F_NAME f_city_name,f.f_grid_nm f_gridid_name
from T_BASE_BUILDADM t
left join v_base_sex  a on t.f_sex= a.F_ID
left join v_base_nation  b on t.f_nation= b.F_ID
left join v_base_status  c on t.f_politics= c.F_ID
left join v_base_edu  d on t.f_education= d.F_ID
left join v_base_regionalism  e on t.f_city= e.F_ID
left join t_base_grid  f on t.f_gridid= f.F_ID
where t.f_visable=1
/
