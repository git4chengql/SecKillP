CREATE VIEW V_BASE_MONTH AS select  to_char(sysdate,'yyyy')||'-01'm0
 from dual union
select to_char(sysdate,'yyyy')||'-02' m1
from dual union
select to_char(sysdate,'yyyy')||'-03' m2 from dual union
select to_char(sysdate,'yyyy')||'-04' m3 from dual union
select to_char(sysdate,'yyyy')||'-05' m4 from dual union
select to_char(sysdate,'yyyy')||'-06' m5 from dual union
select to_char(sysdate,'yyyy')||'-07' m6 from dual union
select to_char(sysdate,'yyyy')||'-08' m7 from dual union
select to_char(sysdate,'yyyy')||'-09' m8 from dual union
select to_char(sysdate,'yyyy')||'-10' m9 from dual union
select to_char(sysdate,'yyyy')||'-11' m10 from dual union
select to_char(sysdate,'yyyy')||'-12' m11 from dual
/
