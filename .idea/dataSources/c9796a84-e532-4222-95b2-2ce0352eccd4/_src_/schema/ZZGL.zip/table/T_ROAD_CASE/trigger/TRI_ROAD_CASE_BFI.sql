CREATE TRIGGER TRI_ROAD_CASE_BFI
BEFORE INSERT
  ON T_ROAD_CASE
FOR EACH ROW
  declare
  -- local variables here
begin
  select SEQ_ROAD_CASE.nextval into :new.f_id from dual;

end tri_road_case_bfi;
/
