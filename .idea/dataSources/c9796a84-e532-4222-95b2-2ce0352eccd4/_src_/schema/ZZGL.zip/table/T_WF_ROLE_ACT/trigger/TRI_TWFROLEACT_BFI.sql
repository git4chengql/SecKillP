CREATE TRIGGER TRI_TWFROLEACT_BFI
BEFORE INSERT
  ON T_WF_ROLE_ACT
FOR EACH ROW
  declare
  -- local variables here
begin
  select SEQ_TWFROLEACT.nextval into :new.id from dual;

end tri_TWFROLEACT_bfi;
/
