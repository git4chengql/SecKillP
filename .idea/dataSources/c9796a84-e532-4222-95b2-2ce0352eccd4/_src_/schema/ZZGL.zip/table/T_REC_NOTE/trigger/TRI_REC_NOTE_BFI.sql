CREATE TRIGGER TRI_REC_NOTE_BFI
BEFORE INSERT
  ON T_REC_NOTE
FOR EACH ROW
  declare
  -- local variables here
begin
  select SEQ_REC_NOTE.nextval into :new.f_id from dual;

end tri_rec_note_bfi;
/
