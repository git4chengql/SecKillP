CREATE TRIGGER TRI_TORECOVERDELAY_BFI
BEFORE INSERT
  ON TORECOVERDELAY
FOR EACH ROW
  declare
  -- local variables here
begin
  select SEQ_TORECOVERDELAY.nextval into :new.f_id from dual;

end tri_torecoverdelay_bfi;
/
