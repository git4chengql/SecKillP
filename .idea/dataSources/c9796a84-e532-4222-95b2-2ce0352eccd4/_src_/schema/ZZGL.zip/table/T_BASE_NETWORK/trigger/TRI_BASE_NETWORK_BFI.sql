CREATE TRIGGER TRI_BASE_NETWORK_BFI
BEFORE INSERT
  ON T_BASE_NETWORK
FOR EACH ROW
  declare
  -- local variables here
begin
  select Seq_Base_Network.nextval into :new.f_id from dual;

end tri_base_network_bfi;
/
