CREATE TRIGGER TRI_PATROL_BFI
BEFORE INSERT
  ON T_WORK_PATROL
FOR EACH ROW
  declare
  -- local variables here
begin
  select Seq_patrol.Nextval into :new.f_id from dual;
end tri_patrol_bfi;
/
