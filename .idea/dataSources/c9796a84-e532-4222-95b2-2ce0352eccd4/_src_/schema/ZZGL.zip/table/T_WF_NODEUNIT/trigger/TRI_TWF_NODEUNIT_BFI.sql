CREATE TRIGGER TRI_TWF_NODEUNIT_BFI
BEFORE INSERT
  ON T_WF_NODEUNIT
FOR EACH ROW
  declare
  -- local variables here
begin
  select SEQ_WF_NODEUNIT.nextval into :new.ID from dual;

end tri_twf_nodeunit_bfi;
/
