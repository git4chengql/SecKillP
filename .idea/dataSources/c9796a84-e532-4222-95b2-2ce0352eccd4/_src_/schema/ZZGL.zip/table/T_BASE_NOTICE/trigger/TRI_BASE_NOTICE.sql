CREATE TRIGGER TRI_BASE_NOTICE
BEFORE INSERT
  ON T_BASE_NOTICE
FOR EACH ROW
  declare
  -- local variables here
begin   --（序列）
  select SEQ_BASE_AREA.nextval into :new.no_id from dual;

end tri_base_notice;
/
