CREATE TRIGGER TRI_SPEC_COMP_PRISION_BFI
BEFORE INSERT
  ON T_SPEC_COMP_PRISION
FOR EACH ROW
  declare
  -- local variables here
begin
  select SEQ_SPEC_COMP_PRISION.nextval into :new.f_id from dual;

end tri_spec_comp_prision_bfi;
/
