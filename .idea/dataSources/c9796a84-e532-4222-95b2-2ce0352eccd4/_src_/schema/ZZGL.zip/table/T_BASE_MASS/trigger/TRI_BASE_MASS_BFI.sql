CREATE TRIGGER TRI_BASE_MASS_BFI
BEFORE INSERT
  ON T_BASE_MASS
FOR EACH ROW
  declare
  -- local variables here
begin
  select Seq_Base_Mass.nextval into :new.f_id from dual;
end tri_base_mass_bfi;
/
