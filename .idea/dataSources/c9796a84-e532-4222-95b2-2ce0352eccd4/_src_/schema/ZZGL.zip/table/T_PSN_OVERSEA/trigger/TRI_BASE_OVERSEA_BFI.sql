CREATE TRIGGER TRI_BASE_OVERSEA_BFI
BEFORE INSERT
  ON T_PSN_OVERSEA
FOR EACH ROW
  declare
  -- local variables here
begin
  select SEQ_BASE_OVERSEA.nextval into :new.f_id from dual;

end tri_base_oversea_bfi;
/
