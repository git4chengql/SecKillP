CREATE TRIGGER TRI_SPEC_DRUG_BFI
BEFORE INSERT
  ON T_SPEC_DRUG
FOR EACH ROW
  declare
  -- local variables here
begin
  select SEQ_SPEC_DRUG.nextval into :new.f_id from dual;

end tri_spec_drug_bfi;
/
