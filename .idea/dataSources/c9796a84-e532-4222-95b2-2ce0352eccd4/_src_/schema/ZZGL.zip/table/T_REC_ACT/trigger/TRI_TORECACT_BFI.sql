CREATE TRIGGER TRI_TORECACT_BFI
BEFORE INSERT
  ON T_REC_ACT
FOR EACH ROW
  declare
  -- local variables here
begin
  select SEQ_TORECACT.nextval into :new.f_id from dual;

end tri_torecact_bfi;
/
