CREATE TRIGGER TRI_PSN_LIVEDETAIL_BFI
BEFORE INSERT
  ON T_PSN_LIVEDETAIL
FOR EACH ROW
  declare
  -- local variables here
begin   --（序列）
  select SEQ_PSN_LIVEDETAIL.nextval into :new.f_id from dual;

end tri_psn_livedetail_bfi;
/
