CREATE TRIGGER TRI_CHECK_IN_BFI
BEFORE INSERT
  ON T_WORK_CHECKIN
FOR EACH ROW
  declare
  -- local variables here
begin
  select Seq_check_in.Nextval into :new.f_id from dual;
end tri_check_in_bfi;
/
