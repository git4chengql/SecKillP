CREATE TRIGGER TRI_SPEC_COMM_SERVICE_BFI
BEFORE INSERT
  ON T_SPEC_COMM_SERVICE
FOR EACH ROW
  declare
  -- local variables here
begin
  select SEQ_SPEC_COMM_SERVICE.nextval into :new.f_id from dual;

end tri_SPEC_COMM_SERVICE_bfi;
/
