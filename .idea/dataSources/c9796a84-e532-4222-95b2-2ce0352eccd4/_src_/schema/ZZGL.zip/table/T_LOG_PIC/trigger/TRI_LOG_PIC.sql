CREATE TRIGGER TRI_LOG_PIC
BEFORE INSERT
  ON T_LOG_PIC
FOR EACH ROW
  BEGIN
   select SEQ_log_pic.Nextval into :new.f_id from dual;
END TRI_log_pic;
/
