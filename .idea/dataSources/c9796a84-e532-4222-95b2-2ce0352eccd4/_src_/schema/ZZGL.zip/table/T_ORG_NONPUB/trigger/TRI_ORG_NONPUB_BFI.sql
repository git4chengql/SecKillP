CREATE TRIGGER TRI_ORG_NONPUB_BFI
BEFORE INSERT
  ON T_ORG_NONPUB
FOR EACH ROW
  declare
  -- local variables here
begin
  select Seq_Base_Nonpub_Org.nextval into :new.f_id from dual;
end tri_org_nonpub_bfi;
/
