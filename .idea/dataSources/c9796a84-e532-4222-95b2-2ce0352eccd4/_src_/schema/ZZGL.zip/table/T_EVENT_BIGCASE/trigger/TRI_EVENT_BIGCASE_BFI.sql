CREATE TRIGGER TRI_EVENT_BIGCASE_BFI
BEFORE INSERT
  ON T_EVENT_BIGCASE
FOR EACH ROW
  declare
  -- local variables here
begin
  select SEQ_EVENT_BIGCASE.nextval into :new.f_id from dual;
end tri_event_bigcase_bfi;
/
