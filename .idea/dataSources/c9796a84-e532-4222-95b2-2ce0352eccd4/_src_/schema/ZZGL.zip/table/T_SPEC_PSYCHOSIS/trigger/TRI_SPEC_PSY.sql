CREATE TRIGGER TRI_SPEC_PSY
BEFORE INSERT
  ON T_SPEC_PSYCHOSIS
FOR EACH ROW
  declare
  -- local variables here
begin
  select SEQ_SPEC_PSYCHOSIS.nextval into :new.f_id from dual;

end tri_spec_psy;
/
