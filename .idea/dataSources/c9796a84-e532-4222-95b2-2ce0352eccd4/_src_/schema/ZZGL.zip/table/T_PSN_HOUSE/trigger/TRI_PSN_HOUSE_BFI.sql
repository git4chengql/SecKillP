CREATE TRIGGER TRI_PSN_HOUSE_BFI
BEFORE INSERT
  ON T_PSN_HOUSE
FOR EACH ROW
  declare
  -- local variables here
begin   --（序列）
  select SEQ_PSN_HOUSE.nextval into :new.f_id from dual;

end tri_psn_house_bfi;
/
