CREATE TRIGGER TRI_SPEC_COMM_BFI
BEFORE INSERT
  ON T_SPEC_COMM
FOR EACH ROW
  declare
  -- local variables here
begin
  select SEQ_SPEC_COMM.nextval into :new.f_id from dual;

end tri_spec_comm_bfi;
/
