CREATE TRIGGER TRI_PSN_LSRY_BFI
BEFORE INSERT
  ON T_PSN_LSRY
FOR EACH ROW
  declare
  -- local variables here
begin
  select SEQ_PSN_LSRY.nextval into :new.f_id from dual;

end tri_PSN_lsry_bfi;
/
