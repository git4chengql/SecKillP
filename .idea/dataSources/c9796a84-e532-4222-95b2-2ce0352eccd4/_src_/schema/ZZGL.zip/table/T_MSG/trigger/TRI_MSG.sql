CREATE TRIGGER TRI_MSG
BEFORE INSERT
  ON T_MSG
FOR EACH ROW
  BEGIN
   select SEQ_msg.nextval into :new.f_id from dual;
END TRI_msg;
/
