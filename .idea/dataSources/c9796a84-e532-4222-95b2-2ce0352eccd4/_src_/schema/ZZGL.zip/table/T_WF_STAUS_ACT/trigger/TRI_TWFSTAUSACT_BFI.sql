CREATE TRIGGER TRI_TWFSTAUSACT_BFI
BEFORE INSERT
  ON T_WF_STAUS_ACT
FOR EACH ROW
  declare
  -- local variables here
begin
  select SEQ_TWFSTAUSACT.nextval into :new.ID from dual;

end tri_TWFSTAUSACT_bfi;
/
