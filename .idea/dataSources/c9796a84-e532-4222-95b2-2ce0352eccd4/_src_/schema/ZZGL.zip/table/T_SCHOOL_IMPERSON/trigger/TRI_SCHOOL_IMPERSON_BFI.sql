CREATE TRIGGER TRI_SCHOOL_IMPERSON_BFI
BEFORE INSERT
  ON T_SCHOOL_IMPERSON
FOR EACH ROW
  declare
  -- local variables here
begin
  select SEQ_BASE_SCHOOL_IMPERSON.NEXTVAL into :new.f_id from dual;

end tri_SCHOOL_IMPERSON_bfi;
/
