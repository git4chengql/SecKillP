CREATE TRIGGER TRI_LOG
BEFORE INSERT
  ON T_LOG
FOR EACH ROW
  BEGIN
   select SEQ_log.Nextval into :new.f_id from dual;
END TRI_log;
/
