CREATE TRIGGER TRI_SECU_KEYAREAS_BFI
BEFORE INSERT
  ON T_SECU_KEYAREAS
FOR EACH ROW
  declare
  -- local variables here
begin
  select SEQ_SECU_KEYAREAS.NEXTVAL into :new.f_id from dual;

end tri_SECU_KEYAREAS_bfi;
/
