CREATE TRIGGER TRI_VERTASK
BEFORE INSERT
  ON T_VER_TASK
FOR EACH ROW
  BEGIN
   select SEQ_VER_TASK.Nextval into :new.f_id from dual;
END TRI_vertask;
/
