CREATE TRIGGER TRI_SPEC_ADIS_BFI
BEFORE INSERT
  ON T_SPEC_ADIS
FOR EACH ROW
  declare
  -- local variables here
begin
  select SEQ_SPEC_ADIS.nextval into :new.f_id from dual;

end tri_spec_adis_bfi;
/
