CREATE TRIGGER TRI_ORG_SCHOOL_MAIN_BFI
BEFORE INSERT
  ON T_SCHOOL_MAIN
FOR EACH ROW
  declare
  -- local variables here
begin
  select Seq_Base_School.nextval into :new.f_id from dual;
end tri_org_school_main_bfi;
/
