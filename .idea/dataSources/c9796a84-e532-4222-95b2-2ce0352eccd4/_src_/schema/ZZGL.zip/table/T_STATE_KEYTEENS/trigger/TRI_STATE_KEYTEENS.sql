CREATE TRIGGER TRI_STATE_KEYTEENS
BEFORE INSERT
  ON T_STATE_KEYTEENS
FOR EACH ROW
  BEGIN
   select seq_state_keyteens.Nextval into :new.f_id from dual;
END tri_state_keyteens;
/
