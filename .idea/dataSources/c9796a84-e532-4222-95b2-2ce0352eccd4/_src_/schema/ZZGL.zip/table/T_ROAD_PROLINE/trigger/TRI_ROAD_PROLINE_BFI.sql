CREATE TRIGGER TRI_ROAD_PROLINE_BFI
BEFORE INSERT
  ON T_ROAD_PROLINE
FOR EACH ROW
  declare
  -- local variables here
begin
  select SEQ_Road_proline.nextval into :new.f_id from dual;
  
end tri_road_proline_bfi;
/
