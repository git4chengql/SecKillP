CREATE TRIGGER TRI_BASE_CMTPSV_BFI
BEFORE INSERT
  ON T_BASE_CMTPSV
FOR EACH ROW
  declare
  -- local variables here
begin
  select Seq_Base_Cmtpsv.nextval into :new.f_id from dual;

end tri_BASE_CMTPSV_bfi;
/
