CREATE TRIGGER TRI_BASE_BUILDADM_BFI
BEFORE INSERT
  ON T_BASE_BUILDADM
FOR EACH ROW
  declare
  -- local variables here
begin
  select Seq_Base_Buildadm.nextval into :new.f_id from dual;

end tri_base_buildadm_bfi;
/
