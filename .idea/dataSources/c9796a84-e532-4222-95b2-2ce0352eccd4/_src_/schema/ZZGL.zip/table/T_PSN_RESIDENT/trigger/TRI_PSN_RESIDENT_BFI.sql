CREATE TRIGGER TRI_PSN_RESIDENT_BFI
BEFORE INSERT
  ON T_PSN_RESIDENT
FOR EACH ROW
  declare
  -- local variables here
begin
  select SEQ_BASE_RESIDENT.nextval into :new.f_id from dual;

end tri_PSN_RESIDENT_bfi;
/
