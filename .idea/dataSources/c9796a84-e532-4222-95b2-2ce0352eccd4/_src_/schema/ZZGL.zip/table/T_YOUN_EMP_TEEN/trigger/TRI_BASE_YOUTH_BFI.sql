CREATE TRIGGER TRI_BASE_YOUTH_BFI
BEFORE INSERT
  ON T_YOUN_EMP_TEEN
FOR EACH ROW
  declare
  -- local variables here
begin
  select SEQ_BASE_YOUTH.nextval into :new.f_id from dual;

end tri_base_youth_bfi;
/
