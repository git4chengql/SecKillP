CREATE TRIGGER TRI_ORG_SOCIAL_BFI
BEFORE INSERT
  ON T_ORG_SOCIAL
FOR EACH ROW
  declare
  -- local variables here
begin
  select Seq_Base_Socialorg.nextval into :new.f_id from dual;
end tri_org_social_bfi;
/
