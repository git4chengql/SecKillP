CREATE TRIGGER SEQ_BASE_SCHOOL
BEFORE INSERT
  ON T_SCHOOL_SAFE
FOR EACH ROW
  declare
  -- local variables here
begin   --（序列）
  select SEQ_BASE_SCHOOL.nextval into :new.f_id from dual;

end SEQ_BASE_SCHOOL;
/
