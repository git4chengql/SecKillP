CREATE TRIGGER TRI_BASE_CENTRAL_BFI
BEFORE INSERT
  ON T_BASE_CENTRAL
FOR EACH ROW
  declare
  -- local variables here
begin
  select SEQ_BASE_CENTRAL.nextval into :new.f_id from dual;

end tri_base_central_bfi;
/
