CREATE TRIGGER TRI_SECU_MURDER_SUSPECT_BFI
BEFORE INSERT
  ON T_SECU_MURDER_SUSPECT
FOR EACH ROW
  declare
  -- local variables here
begin
  select Seq_Base_Murder_Suspect.nextval into :new.f_id from dual;

end tri_SECU_MURDER_SUSPECT_bfi;
/
