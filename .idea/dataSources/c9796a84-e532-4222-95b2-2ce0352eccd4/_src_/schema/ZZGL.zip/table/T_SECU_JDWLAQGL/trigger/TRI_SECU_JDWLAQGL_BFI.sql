CREATE TRIGGER TRI_SECU_JDWLAQGL_BFI
BEFORE INSERT
  ON T_SECU_JDWLAQGL
FOR EACH ROW
  declare
  -- local variables here
begin
  select SEQ_SECU_JDWLAQGL.nextval into :new.f_id from dual;

end tri_SECU_JDWLAQGL_bfi;
/
