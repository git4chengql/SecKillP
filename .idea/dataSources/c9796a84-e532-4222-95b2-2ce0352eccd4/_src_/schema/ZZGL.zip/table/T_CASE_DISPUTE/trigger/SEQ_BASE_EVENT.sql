CREATE TRIGGER SEQ_BASE_EVENT
BEFORE INSERT
  ON T_CASE_DISPUTE
FOR EACH ROW
  declare
  -- local variables here
begin   --（序列）
  select SEQ_BASE_EVENT.nextval into :new.f_id from dual;

end SEQ_BASE_EVENT;
/
