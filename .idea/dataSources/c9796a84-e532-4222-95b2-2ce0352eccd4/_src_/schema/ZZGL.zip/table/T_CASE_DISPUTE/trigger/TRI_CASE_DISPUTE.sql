CREATE TRIGGER TRI_CASE_DISPUTE
BEFORE INSERT
  ON T_CASE_DISPUTE
FOR EACH ROW
  declare
  -- local variables here
begin
  select Seq_case_dispute.nextval into :new.f_id from dual;
end tri_case_dispute;
/
