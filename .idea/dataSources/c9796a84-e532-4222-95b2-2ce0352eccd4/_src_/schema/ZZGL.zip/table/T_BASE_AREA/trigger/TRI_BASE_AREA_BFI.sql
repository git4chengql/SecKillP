CREATE TRIGGER TRI_BASE_AREA_BFI
BEFORE INSERT
  ON T_BASE_AREA
FOR EACH ROW
  declare
  -- local variables here
begin   --（序列）
  select SEQ_BASE_AREA.nextval into :new.fid from dual;

end tri_base_area_bfi;
/
