CREATE VIEW V_BASE_CODE AS select a.f_id,a.f_code, a.f_name, a.f_type,a.f_note1, a.f_note2, a.f_note3, b.f_name f_typename
from t_base_code a
left join (select f_code, f_name from t_base_code where f_type = '0') b
on a.f_type = b.f_code
/
