CREATE VIEW V_BASE_AREA AS select t.fid,t.areaname,t.parentid from  t_base_area t
union
select a.f_id ,a.f_grid_nm,a.f_areaid from  t_base_grid a where a.f_areaid in (select t.fid from  t_base_area t )
/
