CREATE VIEW V_CHENGDE AS select "FID","AREACODE","AREANAME","PARENTCODE","CREATEDATE","PARENTID"
    from T_BASE_AREA
   where parentid=875 or fid=875 or parentid in (select "FID"
    from T_BASE_AREA
   where parentid in (select "FID"
    from T_BASE_AREA
   where parentid=875))
/
