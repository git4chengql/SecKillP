CREATE TRIGGER TRI_RESIDENTNEW0531_BFI
BEFORE INSERT
  ON T_PSN_RESIDENT_NEW0531
FOR EACH ROW
  declare
  -- local variables here
begin
  select SEQ_new0531.nextval into :new.f_id from dual;

end tri_residentnew0531_bfi;
/
