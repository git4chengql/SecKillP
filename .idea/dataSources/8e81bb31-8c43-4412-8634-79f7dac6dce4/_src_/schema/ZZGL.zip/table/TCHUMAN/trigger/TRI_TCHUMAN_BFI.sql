CREATE TRIGGER TRI_TCHUMAN_BFI
BEFORE INSERT
  ON TCHUMAN
FOR EACH ROW
  declare
  -- local variables here
begin
  select Seq_human.Nextval into :new.HUMANID from dual;

end tri_tchuman_bfi;
/
