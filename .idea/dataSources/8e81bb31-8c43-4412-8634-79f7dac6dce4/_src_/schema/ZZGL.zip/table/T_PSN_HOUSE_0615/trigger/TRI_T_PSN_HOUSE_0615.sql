CREATE TRIGGER TRI_T_PSN_HOUSE_0615
BEFORE INSERT
  ON T_PSN_HOUSE_0615
FOR EACH ROW
  declare
  -- local variables here
begin
  select SEQ_T_PSN_HOUSE_0615.nextval into :new.f_id from dual;

end tri_T_PSN_HOUSE_0615;
/
