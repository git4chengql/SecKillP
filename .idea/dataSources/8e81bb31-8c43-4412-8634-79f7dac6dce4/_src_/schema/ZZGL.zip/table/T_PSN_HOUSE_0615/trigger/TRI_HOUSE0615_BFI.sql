CREATE TRIGGER TRI_HOUSE0615_BFI
BEFORE INSERT
  ON T_PSN_HOUSE_0615
FOR EACH ROW
  declare
  -- local variables here
begin   --（序列）
  select SEQ_HOUSE_0615.nextval into :new.f_id from dual;

end tri_house0615_bfi;
/
