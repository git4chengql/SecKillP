CREATE TRIGGER TRI_BASE_GRID_BFI
BEFORE INSERT
  ON T_BASE_GRID
FOR EACH ROW
  declare
  -- local variables here
begin
  select SEQ_BASE_GRID.nextval into :new.f_id from dual;

end tri_base_grid_bfi;
/
