CREATE TRIGGER TRI_GUIFAN0527_BFI
BEFORE INSERT
  ON T_PSN_RESIDENT_NEW0527
FOR EACH ROW
  declare
  -- local variables here
begin
  select seq_guifan0527.nextval into :new.f_id from dual;

end tri_guifan0527_bfi;
/
